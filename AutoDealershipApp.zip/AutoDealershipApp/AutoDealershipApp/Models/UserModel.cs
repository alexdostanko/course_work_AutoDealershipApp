﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoDealershipApp.Models
{
    public class UserModel
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string EmployeeName { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
    }
}