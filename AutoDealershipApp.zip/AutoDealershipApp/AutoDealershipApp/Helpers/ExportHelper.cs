﻿using System;
using System.Data;
using System.IO;
using OfficeOpenXml;
using System.Windows.Forms;

namespace AutoDealershipApp.Helpers
{
    public static class ExportHelper
    {
        public static void ExportToExcel(DataTable dt, string filePath)
        {
            try
            {
                // Проверяем, что лицензия установлена
                if (ExcelPackage.LicenseContext != LicenseContext.NonCommercial)
                {
                    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                }

                using (var package = new ExcelPackage())
                {
                    var worksheet = package.Workbook.Worksheets.Add("Отчет");

                    // Загружаем данные с заголовками
                    worksheet.Cells["A1"].LoadFromDataTable(dt, true);

                    // Автоподбор ширины колонок
                    if (worksheet.Dimension != null)
                        worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                    // Сохраняем файл
                    File.WriteAllBytes(filePath, package.GetAsByteArray());

                    MessageBox.Show($"Файл сохранен:\n{filePath}", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте в Excel:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}