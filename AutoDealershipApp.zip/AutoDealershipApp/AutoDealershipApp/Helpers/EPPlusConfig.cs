﻿using OfficeOpenXml;

namespace AutoDealershipApp.Helpers
{
    public static class EPPlusConfig
    {
        public static void Initialize()
        {
            // Устанавливаем лицензию один раз для всего приложения
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }
    }
}