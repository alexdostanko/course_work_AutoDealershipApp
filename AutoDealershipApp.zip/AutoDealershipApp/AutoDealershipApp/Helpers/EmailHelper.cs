﻿using System;
using System.Data;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace AutoDealershipApp.Helpers
{
    public static class EmailHelper
    {
        // Настройки SMTP (ЗАМЕНИТЕ НА СВОИ!)
        private const string SmtpServer = "smtp.gmail.com"; // Для Gmail
        private const int SmtpPort = 587;
        private const string SmtpUser = "sanyadostanko@gmail.com"; // ВАШ EMAIL
        private const string SmtpPassword = "iblx qtyg rhzn tina"; // ВАШ ПАРОЛЬ или пароль приложения

        public static bool SendReportByEmail(string toEmail, DataTable reportData, string reportName)
        {
            try
            {
                // Создаем временный файл Excel
                string tempFile = System.IO.Path.GetTempFileName() + ".xlsx";
                ExportHelper.ExportToExcel(reportData, tempFile);

                // Настройка письма
                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress(SmtpUser);
                    mail.To.Add(toEmail);
                    mail.Subject = $"Отчет {reportName} от {DateTime.Now:dd.MM.yyyy}";
                    mail.Body = $"Здравствуйте!\n\nВо вложении отчет {reportName}.\n\nС уважением,\nАвтосалон";

                    // Добавляем вложение
                    Attachment attachment = new Attachment(tempFile);
                    attachment.Name = $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";
                    mail.Attachments.Add(attachment);

                    // Настройка SMTP клиента
                    using (SmtpClient smtp = new SmtpClient(SmtpServer, SmtpPort))
                    {
                        smtp.Credentials = new NetworkCredential(SmtpUser, SmtpPassword);
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                }

                // Удаляем временный файл
                System.IO.File.Delete(tempFile);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка отправки email:\n{ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Для Gmail нужно создать "Пароль приложения"
        public static void ShowGmailInstructions()
        {
            string instructions =
                "Для отправки через Gmail:\n\n" +
                "1. Включите двухфакторную аутентификацию\n" +
                "2. Создайте 'Пароль приложения':\n" +
                "   - Перейдите: https://myaccount.google.com/apppasswords\n" +
                "   - Выберите 'Почта' и 'Windows Computer'\n" +
                "   - Скопируйте сгенерированный пароль\n\n" +
                "3. Вставьте пароль в код EmailHelper.cs";

            MessageBox.Show(instructions, "Настройка Gmail",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Для Yandex
        public static void ShowYandexInstructions()
        {
            string instructions =
                "Для отправки через Yandex:\n\n" +
                "1. В настройках почты включите:\n" +
                "   - 'IMAP' протокол\n" +
                "   - 'Пароли приложений'\n\n" +
                "2. Создайте пароль приложения для 'Почты'\n" +
                "3. Используйте этот пароль в коде";

            MessageBox.Show(instructions, "Настройка Yandex",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}