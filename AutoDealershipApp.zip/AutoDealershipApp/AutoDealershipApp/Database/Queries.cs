﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace AutoDealershipApp.Database
{
    public static class Queries
    {
        // 1. Топ-10 самых продаваемых моделей
        public static DataTable GetTopSellingModels()
        {
            string query = @"
                SELECT TOP 10 
                    b.BrandName AS 'Марка',
                    m.ModelName AS 'Модель',
                    COUNT(s.SaleID) AS 'Количество продаж',
                    SUM(s.FinalPrice) AS 'Общая выручка',
                    AVG(s.FinalPrice) AS 'Средняя цена'
                FROM Sales s
                INNER JOIN Cars c ON s.CarID = c.CarID
                INNER JOIN CarModels m ON c.ModelID = m.ModelID
                INNER JOIN CarBrands b ON m.BrandID = b.BrandID
                WHERE s.SaleDate >= DATEADD(YEAR, -1, GETDATE())
                GROUP BY b.BrandName, m.ModelName
                ORDER BY COUNT(s.SaleID) DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 2. Анализ эффективности сотрудников
        public static DataTable GetEmployeePerformance()
        {
            string query = @"
                SELECT 
                    e.EmployeeID,
                    e.LastName + ' ' + e.FirstName AS 'Сотрудник',
                    e.Position AS 'Должность',
                    COUNT(DISTINCT s.SaleID) AS 'Продажи',
                    COUNT(DISTINCT td.TestDriveID) AS 'Тест-драйвы',
                    ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка',
                    ISNULL(AVG(s.FinalPrice), 0) AS 'Средний чек',
                    RANK() OVER (ORDER BY SUM(s.FinalPrice) DESC) AS 'Рейтинг'
                FROM Employees e
                LEFT JOIN Sales s ON e.EmployeeID = s.EmployeeID 
                    AND s.SaleDate >= DATEADD(MONTH, -3, GETDATE())
                LEFT JOIN TestDrives td ON e.EmployeeID = td.EmployeeID
                    AND td.ScheduledDate >= DATEADD(MONTH, -3, GETDATE())
                GROUP BY e.EmployeeID, e.LastName, e.FirstName, e.Position
                ORDER BY 'Выручка' DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 3. Анализ покупательской активности клиентов (ИСПРАВЛЕНО)
        public static DataTable GetCustomerAnalysis()
        {
            string query = @"
        WITH CustomerStats AS (
            SELECT 
                c.CustomerID,
                c.LastName + ' ' + c.FirstName + ISNULL(' ' + c.MiddleName, '') AS 'Клиент',
                ISNULL(COUNT(s.SaleID), 0) AS 'Покупок',
                ISNULL(SUM(s.FinalPrice), 0) AS 'Потрачено',
                MAX(s.SaleDate) AS 'Последняя покупка',
                ISNULL(DATEDIFF(DAY, MAX(s.SaleDate), GETDATE()), 999) AS 'Дней с последней покупки'
            FROM Customers c
            LEFT JOIN Sales s ON c.CustomerID = s.CustomerID
            GROUP BY c.CustomerID, c.LastName, c.FirstName, c.MiddleName
        )
        SELECT 
            Клиент,
            Покупок,
            Потрачено,
            CASE 
                WHEN Покупок > 2 AND Потрачено > 5000000 THEN 'VIP'
                WHEN Покупок > 1 THEN 'Постоянный'
                WHEN Покупок = 1 THEN 'Новый'
                ELSE 'Потенциальный'
            END AS 'Категория'
        FROM CustomerStats
        ORDER BY Потрачено DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 4. Отчет по остаткам на складе
        public static DataTable GetInventoryReport()
        {
            string query = @"
                SELECT 
                    b.BrandName AS 'Марка',
                    m.ModelName AS 'Модель',
                    m.BodyType AS 'Кузов',
                    COUNT(c.CarID) AS 'Всего',
                    SUM(CASE WHEN c.Status = 'В наличии' THEN 1 ELSE 0 END) AS 'В наличии',
                    SUM(CASE WHEN c.Status = 'Зарезервирован' THEN 1 ELSE 0 END) AS 'Зарезервировано',
                    SUM(CASE WHEN c.Status = 'Продан' THEN 1 ELSE 0 END) AS 'Продано',
                    MIN(c.Price) AS 'Мин. цена',
                    MAX(c.Price) AS 'Макс. цена',
                    AVG(c.Price) AS 'Средняя цена'
                FROM CarModels m
                INNER JOIN CarBrands b ON m.BrandID = b.BrandID
                LEFT JOIN Cars c ON m.ModelID = c.ModelID
                GROUP BY b.BrandName, m.ModelName, m.BodyType
                ORDER BY b.BrandName, m.ModelName";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 5. Сравнение продаж по месяцам (ИСПРАВЛЕНО)
        public static DataTable GetMonthlySalesComparison()
        {
            string query = @"
        WITH MonthlySales AS (
            SELECT 
                YEAR(s.SaleDate) AS 'Год',
                MONTH(s.SaleDate) AS 'Месяц',
                DATENAME(MONTH, s.SaleDate) AS 'Название месяца',
                COUNT(s.SaleID) AS 'Количество продаж',
                ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка'
            FROM Sales s
            WHERE s.SaleDate >= DATEADD(YEAR, -2, GETDATE())
            GROUP BY YEAR(s.SaleDate), MONTH(s.SaleDate), DATENAME(MONTH, s.SaleDate)
        )
        SELECT 
            [Название месяца] AS 'Месяц',
            [Год],
            [Количество продаж],
            [Выручка]
        FROM MonthlySales
        ORDER BY [Год] DESC, [Месяц]";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 6. Статистика по тест-драйвам
        public static DataTable GetTestDriveStatistics()
        {
            string query = @"
                SELECT 
                    e.LastName + ' ' + e.FirstName AS 'Менеджер',
                    COUNT(td.TestDriveID) AS 'Всего тест-драйвов',
                    SUM(CASE WHEN td.Status = 'Проведен' THEN 1 ELSE 0 END) AS 'Проведено',
                    SUM(CASE WHEN td.Status = 'Отменен' THEN 1 ELSE 0 END) AS 'Отменено',
                    SUM(CASE WHEN td.Status = 'Запланирован' THEN 1 ELSE 0 END) AS 'Запланировано',
                    COUNT(DISTINCT td.CustomerID) AS 'Уникальных клиентов',
                    CAST(SUM(CASE WHEN td.Status = 'Проведен' THEN 1 ELSE 0 END) * 100.0 / 
                         NULLIF(COUNT(td.TestDriveID), 0) AS DECIMAL(5,2)) AS 'Процент проведения'
                FROM Employees e
                LEFT JOIN TestDrives td ON e.EmployeeID = td.EmployeeID
                GROUP BY e.EmployeeID, e.LastName, e.FirstName
                HAVING COUNT(td.TestDriveID) > 0
                ORDER BY 'Всего тест-драйвов' DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 7. Анализ по методам оплаты
        public static DataTable GetPaymentMethodAnalysis()
        {
            string query = @"
                SELECT 
                    s.PaymentMethod AS 'Метод оплаты',
                    COUNT(s.SaleID) AS 'Количество',
                    SUM(s.FinalPrice) AS 'Сумма',
                    AVG(s.FinalPrice) AS 'Средний чек',
                    COUNT(DISTINCT s.CustomerID) AS 'Клиентов',
                    COUNT(DISTINCT CASE WHEN sc.ContractID IS NOT NULL THEN s.SaleID END) AS 'С сервисным контрактом'
                FROM Sales s
                LEFT JOIN ServiceContracts sc ON s.SaleID = sc.SaleID
                GROUP BY s.PaymentMethod
                ORDER BY 'Сумма' DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 8. Длительность нахождения автомобилей в наличии
        public static DataTable GetCarTurnoverTime()
        {
            string query = @"
                SELECT 
                    b.BrandName AS 'Марка',
                    m.ModelName AS 'Модель',
                    c.VIN,
                    c.DateAdded AS 'Дата поступления',
                    s.SaleDate AS 'Дата продажи',
                    DATEDIFF(DAY, c.DateAdded, ISNULL(s.SaleDate, GETDATE())) AS 'Дней в наличии',
                    CASE 
                        WHEN s.SaleID IS NOT NULL THEN 'Продан'
                        ELSE 'В наличии'
                    END AS 'Статус',
                    c.Price AS 'Цена'
                FROM Cars c
                INNER JOIN CarModels m ON c.ModelID = m.ModelID
                INNER JOIN CarBrands b ON m.BrandID = b.BrandID
                LEFT JOIN Sales s ON c.CarID = s.CarID
                ORDER BY 'Дней в наличии' DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 9. Региональный анализ продаж
        public static DataTable GetRegionalSalesAnalysis()
        {
            string query = @"
                WITH RegionalSales AS (
                    SELECT 
                        ISNULL(LEFT(c.Address, CHARINDEX(',', c.Address + ',') - 1), 'Неизвестно') AS 'Город',
                        b.BrandName AS 'Марка',
                        COUNT(s.SaleID) AS 'Продажи в городе',
                        SUM(s.FinalPrice) AS 'Выручка в городе'
                    FROM Sales s
                    INNER JOIN Customers c ON s.CustomerID = c.CustomerID
                    INNER JOIN Cars car ON s.CarID = car.CarID
                    INNER JOIN CarModels m ON car.ModelID = m.ModelID
                    INNER JOIN CarBrands b ON m.BrandID = b.BrandID
                    GROUP BY LEFT(c.Address, CHARINDEX(',', c.Address + ',') - 1), b.BrandName
                )
                SELECT 
                    'Город',
                    'Марка',
                    'Продажи в городе',
                    'Выручка в городе',
                    SUM('Продажи в городе') OVER (PARTITION BY 'Город') AS 'Всего продаж в городе',
                    CAST('Продажи в городе' * 100.0 / SUM('Продажи в городе') OVER (PARTITION BY 'Город') AS DECIMAL(5,2)) AS 'Доля в городе'
                FROM RegionalSales
                ORDER BY 'Выручка в городе' DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // 10. Прогнозирование спроса (скользящее среднее)
        public static DataTable GetDemandForecast()
        {
            string query = @"
                WITH DailySales AS (
                    SELECT 
                        CAST(s.SaleDate AS DATE) AS 'Дата',
                        COUNT(s.SaleID) AS 'Продажи',
                        SUM(s.FinalPrice) AS 'Выручка'
                    FROM Sales s
                    WHERE s.SaleDate >= DATEADD(MONTH, -3, GETDATE())
                    GROUP BY CAST(s.SaleDate AS DATE)
                ),
                MovingAverages AS (
                    SELECT 
                        'Дата',
                        'Продажи',
                        'Выручка',
                        AVG('Продажи') OVER (ORDER BY 'Дата' ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS 'Среднее 7 дней',
                        AVG('Продажи') OVER (ORDER BY 'Дата' ROWS BETWEEN 29 PRECEDING AND CURRENT ROW) AS 'Среднее 30 дней'
                    FROM DailySales
                )
                SELECT 
                    'Дата',
                    'Продажи',
                    'Выручка',
                    'Среднее 7 дней',
                    'Среднее 30 дней',
                    CASE 
                        WHEN 'Среднее 7 дней' > 'Среднее 30 дней' THEN 'Рост спроса'
                        WHEN 'Среднее 7 дней' < 'Среднее 30 дней' THEN 'Спад спроса'
                        ELSE 'Стабильно'
                    END AS 'Тренд'
                FROM MovingAverages
                ORDER BY 'Дата' DESC";

            return DatabaseHelper.ExecuteQuery(query);
        }

        // Выполнение пользовательского запроса (для админа)
        public static DataTable ExecuteCustomQuery(string query, out string error)
        {
            error = null;
            try
            {
                return DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return null;
            }
        }
    }
}