﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace AutoDealershipApp.Database
{
    public static class BackupHelper
    {
        private static readonly string connectionString =
            @"Server=DESKTOP-U90KFOK\SQLEXPRESS;Database=AutoDealership;Trusted_Connection=True;";

        public static bool CreateBackup(string backupPath)
        {
            try
            {
                string fileName = $"AutoDealership_Backup_{DateTime.Now:yyyyMMdd_HHmmss}.bak";
                string fullPath = Path.Combine(backupPath, fileName);

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = $"BACKUP DATABASE AutoDealership TO DISK = '{fullPath}'";
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                // Логируем
                DatabaseHelper.ExecuteNonQuery(
                    "INSERT INTO Logs (ActionType, TableName, NewValue) VALUES ('BACKUP', 'DATABASE', @path)",
                    new[] { new SqlParameter("@path", fullPath) });

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка бэкапа: {ex.Message}", "Ошибка");
                return false;
            }
        }

        public static bool RestoreFromBackup(string backupFile)
        {
            try
            {
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = $@"
                        ALTER DATABASE AutoDealership SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                        RESTORE DATABASE AutoDealership FROM DISK = '{backupFile}' WITH REPLACE;
                        ALTER DATABASE AutoDealership SET MULTI_USER;";

                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка восстановления: {ex.Message}", "Ошибка");
                return false;
            }
        }

        public static void ScheduleBackup(int hour, int minute)
        {
            // Здесь будет планировщик задач
            MessageBox.Show($"Бэкап запланирован ежедневно на {hour:00}:{minute:00}", "Планировщик");
        }
    }
}