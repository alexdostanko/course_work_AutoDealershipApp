using System;
using System.Windows.Forms;
using OfficeOpenXml;
using AutoDealershipApp.Forms;
using AutoDealershipApp.Helpers; // �������� ���� using

namespace AutoDealershipApp
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // ������������� EPPlus
            EPPlusConfig.Initialize();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }
}