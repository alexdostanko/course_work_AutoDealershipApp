﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;
using AutoDealershipApp.Database;

namespace AutoDealershipApp
{
    public partial class LoginForm : MaterialForm
    {
        public LoginForm()
        {
            InitializeComponent();

            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);

            materialSkinManager.Theme = Properties.Settings.Default.IsDarkTheme ?
                MaterialSkinManager.Themes.DARK : MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(
                Primary.Teal800, Primary.Teal900,
                Primary.Teal200, Accent.LightBlue200,
                TextShade.WHITE);

            this.Text = "АВТОСАЛОН";
            this.Size = new Size(450, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            CreateLoginControls();
        }

        private void CreateLoginControls()
        {
            var line = new Panel
            {
                Location = new Point(50, 110),
                Size = new Size(350, 2),
                BackColor = Color.FromArgb(0, 255, 200)
            };

            var txtUsername = new MaterialTextBox
            {
                Hint = "ЛОГИН",
                Location = new Point(75, 140),
                Size = new Size(300, 50),
                Text = "admin",
                UseAccent = true
            };

            var txtPassword = new MaterialTextBox
            {
                Hint = "ПАРОЛЬ",
                Location = new Point(75, 200),
                Size = new Size(300, 50),
                Text = "admin123",
                Password = true,
                UseAccent = true
            };

            var btnLogin = new MaterialButton
            {
                Text = "ВОЙТИ",
                Location = new Point(175, 280),
                Size = new Size(200, 45),
                Type = MaterialButton.MaterialButtonType.Contained,
                Depth = 3
            };
            btnLogin.Click += (s, e) => DoLogin(txtUsername.Text, txtPassword.Text);

            var btnExit = new MaterialButton
            {
                Text = "ВЫХОД",
                Location = new Point(175, 340),
                Size = new Size(100, 35),
                Type = MaterialButton.MaterialButtonType.Contained,
                Depth = 1
            };
            btnExit.Click += (s, e) => Application.Exit();

            this.Controls.AddRange(new Control[] {
                line, txtUsername, txtPassword, btnLogin, btnExit
            });
        }

        private void DoLogin(string username, string password)
        {
            try
            {
                string query = @"
            SELECT 
                u.UserID,
                u.Username,
                u.PasswordHash,
                u.IsActive,
                e.LastName + ' ' + e.FirstName AS EmployeeName,
                r.RoleName
            FROM Users u
            LEFT JOIN Employees e ON u.EmployeeID = e.EmployeeID
            LEFT JOIN UserRoles ur ON u.UserID = ur.UserID
            LEFT JOIN Roles r ON ur.RoleID = r.RoleID
            WHERE u.Username = @username";

                var dt = DatabaseHelper.ExecuteQuery(query, new[] {
            new SqlParameter("@username", username)
        });

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Пользователь не найден!", "Ошибка");
                    return;
                }

                var row = dt.Rows[0];

                bool isActive = Convert.ToBoolean(row["IsActive"]);
                if (!isActive)
                {
                    MessageBox.Show("Пользователь заблокирован!", "Ошибка");
                    return;
                }

                string storedHash = row["PasswordHash"].ToString().Trim();
                string inputHash = ComputeSha256Hash(password);

                

                if (storedHash.Equals(inputHash, StringComparison.OrdinalIgnoreCase))
                {
                    string userRole = row["RoleName"]?.ToString() ?? "User";
                    int userId = Convert.ToInt32(row["UserID"]);
                    string employeeName = row["EmployeeName"]?.ToString() ?? username;

                    var mainForm = new MainForm();
                    mainForm.SetUserRole(userRole, userId);
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Неверный пароль!", "Ошибка");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
            }
        }

        private string ComputeSha256Hash(string rawData)
        {
            using (System.Security.Cryptography.SHA256 sha256Hash = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(rawData));

                System.Text.StringBuilder builder = new System.Text.StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
