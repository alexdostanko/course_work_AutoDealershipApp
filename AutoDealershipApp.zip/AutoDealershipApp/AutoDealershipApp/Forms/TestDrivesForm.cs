﻿using AutoDealershipApp.Database;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AutoDealershipApp.Forms
{
    public partial class TestDrivesForm : Form
    {
        private DataGridView dataGridView;
        private ComboBox cmbStatus;
        private DateTimePicker dtpDate;
        private Panel filterPanel;

        public TestDrivesForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadTestDrives();
        }

        private void CreateInterface()
        {
            // Панель фильтров
            filterPanel = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblStatus = new Label { Text = "Статус:", Location = new Point(10, 20), ForeColor = this.ForeColor, AutoSize = true };

            cmbStatus = new ComboBox
            {
                Location = new Point(70, 17),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbStatus.Items.AddRange(new[] { "Все", "Запланирован", "Проведен", "Отменен" });
            cmbStatus.SelectedIndex = 0;

            var lblDate = new Label { Text = "Дата:", Location = new Point(240, 20), ForeColor = this.ForeColor, AutoSize = true };

            dtpDate = new DateTimePicker
            {
                Location = new Point(290, 17),
                Size = new Size(130, 25),
                Format = DateTimePickerFormat.Short
            };

            var btnApply = new Button
            {
                Text = "ПРИМЕНИТЬ",
                Location = new Point(440, 10),
                Size = new Size(120, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnApply.Click += (s, e) => LoadTestDrives();

            var btnNew = new Button
            {
                Text = "+ ЗАПИСЬ",
                Location = new Point(1000, 10),
                Size = new Size(120, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnNew.Click += (s, e) => ShowTestDriveDialog();

            filterPanel.Controls.AddRange(new Control[] { lblStatus, cmbStatus, lblDate, dtpDate, btnApply, btnNew });

            // DataGridView для тест-драйвов
            dataGridView = new DataGridView
            {
                Location = new Point(0, 60),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 60),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridView.EnableHeadersVisualStyles = false;

            // Обновляем размеры при изменении размера формы
            this.Resize += (s, e) =>
            {
                filterPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 60);
            };

            this.Controls.Add(filterPanel);
            this.Controls.Add(dataGridView);
        }

        // ... остальные методы (LoadTestDrives, ShowTestDriveDialog) остаются без изменений ...
        private void LoadTestDrives()
        {
            string query = @"
                SELECT 
                    td.TestDriveID AS 'ID',
                    CONVERT(NVARCHAR(20), td.ScheduledDate, 104) + ' ' + 
                    CONVERT(NVARCHAR(5), td.ScheduledDate, 108) AS 'Дата и время',
                    b.BrandName + ' ' + m.ModelName AS 'Автомобиль',
                    cust.LastName + ' ' + cust.FirstName AS 'Клиент',
                    e.LastName + ' ' + e.FirstName AS 'Менеджер',
                    td.Status AS 'Статус',
                    td.Notes AS 'Примечания'
                FROM TestDrives td
                JOIN Cars c ON td.CarID = c.CarID
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                JOIN Customers cust ON td.CustomerID = cust.CustomerID
                JOIN Employees e ON td.EmployeeID = e.EmployeeID
                WHERE 1=1";

            if (cmbStatus.SelectedIndex > 0)
                query += $" AND td.Status = '{cmbStatus.Text}'";

            query += $" AND CAST(td.ScheduledDate AS DATE) = '{dtpDate.Value:yyyy-MM-dd}'";
            query += " ORDER BY td.ScheduledDate DESC";

            var dt = DatabaseHelper.ExecuteQuery(query);
            dataGridView.DataSource = dt;

            if (dataGridView.Columns["ID"] != null)
                dataGridView.Columns["ID"].Visible = false;
        }

        private void ShowTestDriveDialog()
        {
            var dialog = new Form
            {
                Text = "Запись на тест-драйв",
                Size = new Size(500, 400),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            var cars = DatabaseHelper.ExecuteQuery(@"
                SELECT c.CarID, b.BrandName + ' ' + m.ModelName + ' (' + c.VIN + ')' AS CarName
                FROM Cars c
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                WHERE c.Status = 'В наличии'");

            var customers = DatabaseHelper.ExecuteQuery("SELECT CustomerID, LastName + ' ' + FirstName AS CustomerName FROM Customers");
            var employees = DatabaseHelper.ExecuteQuery("SELECT EmployeeID, LastName + ' ' + FirstName AS EmployeeName FROM Employees WHERE Position LIKE '%Продавец%'");

            var lblCar = new Label { Text = "Автомобиль:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbCar = new ComboBox
            {
                Location = new Point(130, 20),
                Size = new Size(320, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = cars,
                DisplayMember = "CarName",
                ValueMember = "CarID"
            };

            var lblCustomer = new Label { Text = "Клиент:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbCustomer = new ComboBox
            {
                Location = new Point(130, 60),
                Size = new Size(320, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = customers,
                DisplayMember = "CustomerName",
                ValueMember = "CustomerID"
            };

            var lblEmployee = new Label { Text = "Менеджер:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbEmployee = new ComboBox
            {
                Location = new Point(130, 100),
                Size = new Size(320, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = employees,
                DisplayMember = "EmployeeName",
                ValueMember = "EmployeeID"
            };

            var lblDate = new Label { Text = "Дата и время:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var dtpDateTime = new DateTimePicker
            {
                Location = new Point(130, 140),
                Size = new Size(200, 25),
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "dd.MM.yyyy HH:mm",
                ShowUpDown = true,
                Value = DateTime.Now.AddHours(1)
            };

            var lblNotes = new Label { Text = "Примечания:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtNotes = new TextBox
            {
                Location = new Point(130, 180),
                Size = new Size(320, 50),
                Multiline = true,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            var btnSave = new Button
            {
                Text = "ЗАПИСАТЬ",
                Location = new Point(150, 260),
                Size = new Size(180, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            btnSave.Click += (s, e) =>
            {
                if (cmbCar.SelectedValue == null || cmbCustomer.SelectedValue == null || cmbEmployee.SelectedValue == null)
                {
                    MessageBox.Show("Заполните все поля!", "Ошибка");
                    return;
                }

                try
                {
                    string query = @"
                        INSERT INTO TestDrives (CarID, CustomerID, EmployeeID, ScheduledDate, Status, Notes)
                        VALUES (@car, @cust, @emp, @date, 'Запланирован', @notes)";

                    DatabaseHelper.ExecuteNonQuery(query, new[] {
                        new SqlParameter("@car", cmbCar.SelectedValue),
                        new SqlParameter("@cust", cmbCustomer.SelectedValue),
                        new SqlParameter("@emp", cmbEmployee.SelectedValue),
                        new SqlParameter("@date", dtpDateTime.Value),
                        new SqlParameter("@notes", txtNotes.Text)
                    });

                    MessageBox.Show("Тест-драйв запланирован!", "Успех");
                    dialog.Close();
                    LoadTestDrives();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblCar, cmbCar, lblCustomer, cmbCustomer, lblEmployee, cmbEmployee,
                lblDate, dtpDateTime, lblNotes, txtNotes, btnSave
            });

            dialog.ShowDialog(this);
        }
    }
}