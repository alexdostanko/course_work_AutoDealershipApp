﻿using AutoDealershipApp.Database;
using AutoDealershipApp.Helpers;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace AutoDealershipApp.Forms
{
    public partial class ReportsForm : Form
    {
        private DataTable currentReportData;
        private DataGridView dataGridView;
        private TabControl tabControl;
        private Chart chartSales;
        private Panel panel, exportPanel;

        public ReportsForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
        }

        private void CreateInterface()
        {
            int currentY = 0;

            // Панель с кнопками отчетов
            panel = new Panel
            {
                Location = new Point(0, currentY),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            currentY += 60;

            var btnCarsReport = CreateReportButton("АВТО", new Point(10, 10));
            var btnSalesReport = CreateReportButton("ПРОДАЖИ", new Point(130, 10));
            var btnCustomersReport = CreateReportButton("КЛИЕНТЫ", new Point(250, 10));
            var btnInventoryReport = CreateReportButton("СКЛАД", new Point(370, 10));
            var btnEmployeesReport = CreateReportButton("СОТРУДНИКИ", new Point(490, 10));

            panel.Controls.AddRange(new[] {
                btnCarsReport, btnSalesReport, btnCustomersReport,
                btnInventoryReport, btnEmployeesReport
            });

            // Панель экспорта
            exportPanel = new Panel
            {
                Location = new Point(0, currentY),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(30, 30, 30) : Color.FromArgb(230, 230, 230),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            currentY += 60;

            var btnExcel = new Button
            {
                Text = "ЭКСПОРТ В EXCEL",
                Location = new Point(10, 10),
                Size = new Size(150, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            var btnPrint = new Button
            {
                Text = "ПЕЧАТЬ",
                Location = new Point(170, 10),
                Size = new Size(120, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };

            var btnEmail = new Button
            {
                Text = "ОТПРАВИТЬ НА EMAIL",
                Location = new Point(300, 10),
                Size = new Size(160, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };

            var btnPdf = new Button
            {
                Text = "ЭКСПОРТ В PDF",
                Location = new Point(470, 10),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };

            exportPanel.Controls.AddRange(new[] { btnExcel, btnPrint, btnEmail, btnPdf });

            // TabControl
            tabControl = new TabControl
            {
                Location = new Point(0, currentY),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - currentY),
                BackColor = this.BackColor,
                ForeColor = this.ForeColor,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            // Вкладка "Таблицы"
            var tabTables = new TabPage("Таблицы");
            tabTables.BackColor = this.BackColor;

            dataGridView = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridView.EnableHeadersVisualStyles = false;

            tabTables.Controls.Add(dataGridView);

            // Вкладка "Графики"
            var tabCharts = new TabPage("Графики");
            tabCharts.BackColor = this.BackColor;

            var chartButtonPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240)
            };

            var btnMonthlySales = new Button
            {
                Text = "ПРОДАЖИ ПО МЕСЯЦАМ",
                Location = new Point(10, 5),
                Size = new Size(180, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            var btnTopCars = new Button
            {
                Text = "ТОП-5 АВТО",
                Location = new Point(200, 5),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            var btnEmployeeStats = new Button
            {
                Text = "ЭФФЕКТИВНОСТЬ",
                Location = new Point(350, 5),
                Size = new Size(160, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            chartButtonPanel.Controls.AddRange(new[] { btnMonthlySales, btnTopCars, btnEmployeeStats });

            chartSales = new Chart
            {
                Dock = DockStyle.Fill,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            var chartArea = new ChartArea();
            chartArea.BackColor = this.BackColor;
            chartArea.AxisX.LabelStyle.ForeColor = this.ForeColor;
            chartArea.AxisY.LabelStyle.ForeColor = this.ForeColor;
            chartArea.AxisX.LineColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            chartArea.AxisY.LineColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            chartArea.AxisX.MajorGrid.LineColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200);
            chartArea.AxisY.MajorGrid.LineColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200);
            chartSales.ChartAreas.Add(chartArea);

            tabCharts.Controls.Add(chartSales);
            tabCharts.Controls.Add(chartButtonPanel);

            tabControl.TabPages.Add(tabTables);
            tabControl.TabPages.Add(tabCharts);

            // Обновляем размеры при изменении размера формы
            this.Resize += (s, e) =>
            {
                panel.Width = this.ClientSize.Width;
                exportPanel.Width = this.ClientSize.Width;
                tabControl.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - currentY);
            };

            // ============ ОБРАБОТЧИКИ КНОПОК ОТЧЕТОВ ============
            btnCarsReport.Click += (s, e) =>
            {
                try
                {
                    currentReportData = DatabaseHelper.ExecuteQuery(@"
                        SELECT b.BrandName AS 'Марка', m.ModelName AS 'Модель',
                               c.VIN, c.Year AS 'Год', c.Color AS 'Цвет',
                               c.Price AS 'Цена', c.Status AS 'Статус'
                        FROM Cars c
                        JOIN CarModels m ON c.ModelID = m.ModelID
                        JOIN CarBrands b ON m.BrandID = b.BrandID");
                    dataGridView.DataSource = currentReportData;
                    tabControl.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки отчета: {ex.Message}", "Ошибка");
                }
            };

            btnSalesReport.Click += (s, e) =>
            {
                try
                {
                    currentReportData = DatabaseHelper.ExecuteQuery(@"
                        SELECT s.SaleDate AS 'Дата', 
                               c.VIN,
                               cust.LastName + ' ' + cust.FirstName AS 'Клиент',
                               s.FinalPrice AS 'Цена',
                               s.PaymentMethod AS 'Оплата'
                        FROM Sales s
                        JOIN Cars c ON s.CarID = c.CarID
                        JOIN Customers cust ON s.CustomerID = cust.CustomerID
                        ORDER BY s.SaleDate DESC");
                    dataGridView.DataSource = currentReportData;
                    tabControl.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки отчета: {ex.Message}", "Ошибка");
                }
            };

            btnCustomersReport.Click += (s, e) =>
            {
                try
                {
                    currentReportData = Queries.GetCustomerAnalysis();
                    dataGridView.DataSource = currentReportData;
                    tabControl.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки отчета: {ex.Message}", "Ошибка");
                }
            };

            btnInventoryReport.Click += (s, e) =>
            {
                try
                {
                    currentReportData = Queries.GetInventoryReport();
                    dataGridView.DataSource = currentReportData;
                    tabControl.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки отчета: {ex.Message}", "Ошибка");
                }
            };

            btnEmployeesReport.Click += (s, e) =>
            {
                try
                {
                    currentReportData = Queries.GetEmployeePerformance();
                    dataGridView.DataSource = currentReportData;
                    tabControl.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки отчета: {ex.Message}", "Ошибка");
                }
            };

            // ============ ОБРАБОТЧИКИ ГРАФИКОВ ============
            btnMonthlySales.Click += (s, e) =>
            {
                try
                {
                    var dt = DatabaseHelper.ExecuteQuery(@"
                        SELECT DATENAME(MONTH, SaleDate) AS 'Месяц',
                               COUNT(*) AS 'Продажи',
                               SUM(FinalPrice) AS 'Выручка'
                        FROM Sales
                        WHERE SaleDate >= DATEADD(YEAR, -1, GETDATE())
                        GROUP BY DATENAME(MONTH, SaleDate), MONTH(SaleDate)
                        ORDER BY MONTH(SaleDate)");

                    chartSales.Series.Clear();

                    var seriesSales = new Series("Продажи по месяцам");
                    seriesSales.ChartType = SeriesChartType.Column;
                    seriesSales.Color = Properties.Settings.Default.IsDarkTheme ?
                        Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
                    seriesSales.IsValueShownAsLabel = true;
                    chartSales.Series.Add(seriesSales);

                    foreach (DataRow row in dt.Rows)
                    {
                        var point = seriesSales.Points.Add(Convert.ToDouble(row["Продажи"]));
                        point.AxisLabel = row["Месяц"].ToString();
                    }

                    tabControl.SelectedIndex = 1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки графика: {ex.Message}", "Ошибка");
                }
            };

            btnTopCars.Click += (s, e) =>
            {
                try
                {
                    var dt = DatabaseHelper.ExecuteQuery(@"
                        SELECT TOP 5 
                            b.BrandName + ' ' + m.ModelName AS 'Авто',
                            COUNT(*) AS 'Продажи'
                        FROM Sales s
                        JOIN Cars c ON s.CarID = c.CarID
                        JOIN CarModels m ON c.ModelID = m.ModelID
                        JOIN CarBrands b ON m.BrandID = b.BrandID
                        GROUP BY b.BrandName, m.ModelName
                        ORDER BY COUNT(*) DESC");

                    chartSales.Series.Clear();

                    var seriesPie = new Series("Топ-5 автомобилей");
                    seriesPie.ChartType = SeriesChartType.Pie;
                    seriesPie.Color = Properties.Settings.Default.IsDarkTheme ?
                        Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
                    seriesPie.IsValueShownAsLabel = true;
                    seriesPie.LabelForeColor = this.ForeColor;
                    chartSales.Series.Add(seriesPie);

                    foreach (DataRow row in dt.Rows)
                    {
                        var point = seriesPie.Points.Add(Convert.ToDouble(row["Продажи"]));
                        point.LegendText = row["Авто"].ToString();
                        point.Label = row["Продажи"].ToString();
                    }

                    tabControl.SelectedIndex = 1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки графика: {ex.Message}", "Ошибка");
                }
            };

            btnEmployeeStats.Click += (s, e) =>
            {
                try
                {
                    var dt = DatabaseHelper.ExecuteQuery(@"
                        SELECT 
                            e.LastName + ' ' + e.FirstName AS 'Сотрудник',
                            COUNT(s.SaleID) AS 'Продажи'
                        FROM Employees e
                        LEFT JOIN Sales s ON e.EmployeeID = s.EmployeeID
                        GROUP BY e.LastName, e.FirstName
                        ORDER BY Продажи DESC");

                    chartSales.Series.Clear();

                    var seriesBars = new Series("Продажи по сотрудникам");
                    seriesBars.ChartType = SeriesChartType.Bar;
                    seriesBars.Color = Properties.Settings.Default.IsDarkTheme ?
                        Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
                    seriesBars.IsValueShownAsLabel = true;
                    chartSales.Series.Add(seriesBars);

                    foreach (DataRow row in dt.Rows)
                    {
                        var point = seriesBars.Points.Add(Convert.ToDouble(row["Продажи"]));
                        point.AxisLabel = row["Сотрудник"].ToString();
                    }

                    tabControl.SelectedIndex = 1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки графика: {ex.Message}", "Ошибка");
                }
            };

            // ============ ОБРАБОТЧИКИ ЭКСПОРТА ============
            btnExcel.Click += (s, e) =>
            {
                if (currentReportData != null && currentReportData.Rows.Count > 0)
                {
                    SaveFileDialog sfd = new SaveFileDialog
                    {
                        Filter = "Excel Files|*.xlsx",
                        FileName = $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                    };

                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        ExportHelper.ExportToExcel(currentReportData, sfd.FileName);
                    }
                }
                else
                {
                    MessageBox.Show("Нет данных для экспорта!", "Предупреждение");
                }
            };

            btnPrint.Click += (s, e) =>
            {
                if (currentReportData != null && currentReportData.Rows.Count > 0)
                {
                    PrintReport(dataGridView);
                }
                else
                {
                    MessageBox.Show("Нет данных для печати!", "Предупреждение");
                }
            };

            btnEmail.Click += (s, e) =>
            {
                if (currentReportData != null && currentReportData.Rows.Count > 0)
                {
                    string toEmail = Microsoft.VisualBasic.Interaction.InputBox(
                        "Введите email получателя:", "Отправка отчета", "");

                    if (string.IsNullOrEmpty(toEmail)) return;

                    string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    string fileName = $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";
                    string fullPath = Path.Combine(desktopPath, fileName);

                    ExportHelper.ExportToExcel(currentReportData, fullPath);

                    MessageBox.Show($"Отчет сохранен:\n{fullPath}\n\n" +
                        $"Отправьте его на {toEmail} через ваш почтовый клиент.",
                        "Информация");
                }
                else
                {
                    MessageBox.Show("Нет данных для отправки!", "Предупреждение");
                }
            };

            btnPdf.Click += (s, e) =>
            {
                if (currentReportData != null && currentReportData.Rows.Count > 0)
                {
                    SaveFileDialog sfd = new SaveFileDialog
                    {
                        Filter = "PDF Files|*.pdf|Excel Files|*.xlsx",
                        FileName = $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.pdf"
                    };

                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        ExportToPdf(currentReportData, sfd.FileName);
                    }
                }
                else
                {
                    MessageBox.Show("Нет данных для экспорта!", "Предупреждение");
                }
            };

            this.Controls.Add(panel);
            this.Controls.Add(exportPanel);
            this.Controls.Add(tabControl);
        }

        private Button CreateReportButton(string text, Point location)
        {
            return new Button
            {
                Text = text,
                Location = location,
                Size = new Size(110, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
        }

        private void PrintReport(DataGridView dgv)
        {
            try
            {
                if (dgv.DataSource == null)
                {
                    MessageBox.Show("Нет данных для печати!", "Предупреждение");
                    return;
                }

                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string fileName = $"Print_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";
                string fullPath = Path.Combine(desktopPath, fileName);

                ExportHelper.ExportToExcel((DataTable)dgv.DataSource, fullPath);

                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = fullPath,
                    UseShellExecute = true
                });

                MessageBox.Show("Файл открыт в Excel. Используйте Файл → Печать для печати.", "Информация");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подготовке к печати:\n{ex.Message}", "Ошибка");
            }
        }

        private void ExportToPdf(DataTable dt, string filePath)
        {
            try
            {
                if (filePath.EndsWith(".pdf"))
                {
                    string excelPath = filePath.Replace(".pdf", ".xlsx");
                    ExportHelper.ExportToExcel(dt, excelPath);

                    MessageBox.Show($"Создан Excel файл:\n{excelPath}\n\n" +
                        "Для создания PDF:\n" +
                        "1. Откройте файл в Excel\n" +
                        "2. Нажмите Файл → Сохранить как\n" +
                        "3. Выберите тип файла PDF",
                        "Информация");
                }
                else
                {
                    ExportHelper.ExportToExcel(dt, filePath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}", "Ошибка");
            }
        }
    }
}