﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using AutoDealershipApp.Database;
using System.Data.SqlClient;

namespace AutoDealershipApp.Forms
{
    public partial class PaymentsForm : Form
    {
        private DataGridView dataGridView;
        private ComboBox cmbPeriod;
        private DateTimePicker dtpFrom, dtpTo;
        private Label lblTotal;
        private Button btnAdd;

        public PaymentsForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadPayments();
        }

        private void CreateInterface()
        {
            int currentY = 0;

            // Заголовок
            var lblTitle = new Label
            {
                Text = "💰 ПЛАТЕЖИ КЛИЕНТОВ",
                Font = new Font("Century Gothic", 18, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(20, 10),
                Size = new Size(500, 40)
            };
            this.Controls.Add(lblTitle);
            currentY = 60;

            // Панель фильтров
            var filterPanel = new Panel
            {
                Location = new Point(0, currentY),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            currentY += 60;

            var lblPeriod = new Label
            {
                Text = "Период:",
                Location = new Point(20, 20),
                ForeColor = this.ForeColor,
                AutoSize = true
            };

            cmbPeriod = new ComboBox
            {
                Location = new Point(80, 17),
                Size = new Size(120, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbPeriod.Items.AddRange(new[] { "Все", "Сегодня", "Неделя", "Месяц", "Год", "Произвольно" });
            cmbPeriod.SelectedIndex = 0;
            cmbPeriod.SelectedIndexChanged += (s, e) => UpdateDateRange();

            dtpFrom = new DateTimePicker
            {
                Location = new Point(210, 17),
                Size = new Size(130, 25),
                Value = DateTime.Now.AddMonths(-1),
                Format = DateTimePickerFormat.Short,
                Enabled = false
            };

            dtpTo = new DateTimePicker
            {
                Location = new Point(350, 17),
                Size = new Size(130, 25),
                Value = DateTime.Now,
                Format = DateTimePickerFormat.Short,
                Enabled = false
            };

            var btnApply = new Button
            {
                Text = "ПРИМЕНИТЬ",
                Location = new Point(500, 10),
                Size = new Size(120, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnApply.Click += (s, e) => LoadPayments();

            btnAdd = new Button
            {
                Text = "+ НОВЫЙ ПЛАТЕЖ",
                Location = new Point(900, 10),
                Size = new Size(140, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnAdd.Click += (s, e) => ShowPaymentDialog();

            filterPanel.Controls.AddRange(new Control[] {
                lblPeriod, cmbPeriod, dtpFrom, dtpTo, btnApply, btnAdd
            });
            this.Controls.Add(filterPanel);

            // Панель статистики
            var statsPanel = new Panel
            {
                Location = new Point(0, currentY),
                Size = new Size(this.ClientSize.Width, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(30, 30, 30) : Color.FromArgb(230, 230, 230),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            currentY += 40;

            lblTotal = new Label
            {
                Location = new Point(20, 10),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                AutoSize = true,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            statsPanel.Controls.Add(lblTotal);
            this.Controls.Add(statsPanel);

            // Таблица платежей
            dataGridView = new DataGridView
            {
                Location = new Point(0, currentY),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - currentY),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            // Стили
            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.EnableHeadersVisualStyles = false;

            this.Controls.Add(dataGridView);

            // Обработчик изменения размера
            this.Resize += (s, e) =>
            {
                filterPanel.Width = this.ClientSize.Width;
                statsPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - currentY);
            };
        }

        private void UpdateDateRange()
        {
            bool custom = cmbPeriod.SelectedIndex == 5;
            dtpFrom.Enabled = custom;
            dtpTo.Enabled = custom;

            if (!custom && cmbPeriod.SelectedIndex > 0)
            {
                switch (cmbPeriod.SelectedIndex)
                {
                    case 1: // Сегодня
                        dtpFrom.Value = DateTime.Today;
                        dtpTo.Value = DateTime.Today;
                        break;
                    case 2: // Неделя
                        dtpFrom.Value = DateTime.Today.AddDays(-7);
                        dtpTo.Value = DateTime.Today;
                        break;
                    case 3: // Месяц
                        dtpFrom.Value = DateTime.Today.AddMonths(-1);
                        dtpTo.Value = DateTime.Today;
                        break;
                    case 4: // Год
                        dtpFrom.Value = DateTime.Today.AddYears(-1);
                        dtpTo.Value = DateTime.Today;
                        break;
                }
            }
        }

        private void LoadPayments()
        {
            try
            {
                string query = @"
                    SELECT 
                        s.SaleID AS 'ID',
                        CONVERT(NVARCHAR(20), s.SaleDate, 104) AS 'Дата',
                        b.BrandName + ' ' + m.ModelName AS 'Автомобиль',
                        c.VIN,
                        cust.LastName + ' ' + cust.FirstName AS 'Клиент',
                        FORMAT(s.FinalPrice, 'N0') + ' ₽' AS 'Сумма',
                        s.PaymentMethod AS 'Способ оплаты',
                        CASE 
                            WHEN s.PaymentMethod IS NOT NULL THEN 'Проведен'
                            ELSE 'Не указан'
                        END AS 'Статус'
                    FROM Sales s
                    JOIN Cars c ON s.CarID = c.CarID
                    JOIN CarModels m ON c.ModelID = m.ModelID
                    JOIN CarBrands b ON m.BrandID = b.BrandID
                    JOIN Customers cust ON s.CustomerID = cust.CustomerID";

                if (cmbPeriod.SelectedIndex > 0)
                {
                    query += $" WHERE s.SaleDate BETWEEN '{dtpFrom.Value:yyyy-MM-dd}' AND '{dtpTo.Value:yyyy-MM-dd}'";
                }

                query += " ORDER BY s.SaleDate DESC";

                var dt = DatabaseHelper.ExecuteQuery(query);
                dataGridView.DataSource = dt;

                if (dataGridView.Columns["ID"] != null)
                    dataGridView.Columns["ID"].Visible = false;

                UpdateTotal(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки платежей: {ex.Message}");
            }
        }

        private void UpdateTotal(DataTable dt)
        {
            decimal total = 0;
            foreach (DataRow row in dt.Rows)
            {
                string amount = row["Сумма"].ToString().Replace(" ₽", "").Replace(" ", "");
                if (decimal.TryParse(amount, out decimal val))
                    total += val;
            }
            lblTotal.Text = $"💰 Общая сумма платежей: {total:N0} ₽";
        }

        private void ShowPaymentDialog()
        {
            var dialog = new Form
            {
                Text = "Новый платеж",
                Size = new Size(450, 400),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            // Загружаем продажи (все, можно выбрать любую)
            var sales = DatabaseHelper.ExecuteQuery(@"
                SELECT s.SaleID, 
                       b.BrandName + ' ' + m.ModelName + ' - ' + cust.LastName + ' ' + FORMAT(s.FinalPrice, 'N0') + '₽' AS SaleInfo
                FROM Sales s
                JOIN Cars c ON s.CarID = c.CarID
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                JOIN Customers cust ON s.CustomerID = cust.CustomerID
                ORDER BY s.SaleDate DESC");

            var lblSale = new Label { Text = "Продажа:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbSale = new ComboBox
            {
                Location = new Point(130, 20),
                Size = new Size(280, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = sales,
                DisplayMember = "SaleInfo",
                ValueMember = "SaleID"
            };

            var lblAmount = new Label { Text = "Сумма:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtAmount = new TextBox
            {
                Location = new Point(130, 60),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var lblMethod = new Label { Text = "Способ:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbMethod = new ComboBox
            {
                Location = new Point(130, 100),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbMethod.Items.AddRange(new[] { "Наличные", "Карта", "Кредит", "Trade-in" });

            var lblStatus = new Label { Text = "Статус:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbStatus = new ComboBox
            {
                Location = new Point(130, 140),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbStatus.Items.AddRange(new[] { "Ожидает", "Проведен", "Отменен" });

            var lblDate = new Label { Text = "Дата:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var dtpDate = new DateTimePicker
            {
                Location = new Point(130, 180),
                Size = new Size(150, 25),
                Value = DateTime.Now,
                Format = DateTimePickerFormat.Short
            };

            var btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Location = new Point(130, 250),
                Size = new Size(180, 40),
                BackColor = btnAdd.BackColor,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            btnSave.Click += (s, e) =>
            {
                if (cmbSale.SelectedValue == null || string.IsNullOrWhiteSpace(txtAmount.Text))
                {
                    MessageBox.Show("Заполните все поля!");
                    return;
                }

                try
                {
                    // Обновляем информацию о платеже в таблице Sales
                    string query = @"
                        UPDATE Sales 
                        SET PaymentMethod = @method,
                            Notes = ISNULL(Notes, '') + ' | Платеж от ' + CONVERT(NVARCHAR(10), @date, 104)
                        WHERE SaleID = @sale";

                    DatabaseHelper.ExecuteNonQuery(query, new[] {
                        new SqlParameter("@sale", cmbSale.SelectedValue),
                        new SqlParameter("@method", cmbMethod.Text),
                        new SqlParameter("@date", dtpDate.Value)
                    });

                    MessageBox.Show("Платеж добавлен!");
                    dialog.Close();
                    LoadPayments();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblSale, cmbSale, lblAmount, txtAmount, lblMethod, cmbMethod,
                lblStatus, cmbStatus, lblDate, dtpDate, btnSave
            });

            dialog.ShowDialog(this);
        }
    }
}