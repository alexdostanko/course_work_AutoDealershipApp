﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;
using AutoDealershipApp.Forms;

namespace AutoDealershipApp
{
    public partial class BaseForm : MaterialForm
    {
        protected MaterialSkinManager materialSkinManager;
        protected Panel sideMenu;
        protected Panel contentPanel;
        protected bool isDarkTheme = true;
        private MaterialButton btnTheme;
        protected string userRole = "Admin";
        protected int userId = 1;

        public BaseForm()
        {
            InitializeComponent();
            SetupTheme();
            CreateSideMenu();
        }

        public void SetUserRole(string role, int id)
        {
            userRole = role;
            userId = id;

            if (sideMenu != null)
            {
                sideMenu.Controls.Clear();
                CreateSideMenu();
            }
        }

        protected virtual void SetupTheme()
        {
            materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);

            try
            {
                isDarkTheme = Properties.Settings.Default.IsDarkTheme;
            }
            catch
            {
                isDarkTheme = true;
            }
            ApplyTheme();
        }

        protected void ApplyTheme()
        {
            if (contentPanel != null)
            {
                contentPanel.BackColor = isDarkTheme ? Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
                contentPanel.BorderStyle = BorderStyle.None;
            }
            if (isDarkTheme)
            {
                materialSkinManager.Theme = MaterialSkinManager.Themes.DARK;
                materialSkinManager.ColorScheme = new ColorScheme(
                    Primary.Teal800, Primary.Teal900,
                    Primary.Teal200, Accent.LightBlue200,
                    TextShade.WHITE);
            }
            else
            {
                materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
                materialSkinManager.ColorScheme = new ColorScheme(
                    Primary.Teal500, Primary.Teal600,
                    Primary.Teal200, Accent.LightBlue200,
                    TextShade.BLACK);
            }

            if (sideMenu != null)
            {
                sideMenu.BackColor = isDarkTheme ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240);
            }

            if (btnTheme != null)
            {
                btnTheme.Text = isDarkTheme ? "☀️ СВЕТЛАЯ" : "🌙 ТЕМНАЯ";
            }
        }

        protected virtual void CreateSideMenu()
        {
            // Сначала создаем contentPanel с явным цветом для проверки
            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = isDarkTheme ? Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255),
                BorderStyle = BorderStyle.None  // ← добавь эту строку
            };

            sideMenu = new Panel
            {
                Dock = DockStyle.Left,
                Width = 147,
                BackColor = isDarkTheme ? Color.FromArgb(30, 30, 30) : Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.None  // ← добавь эту строку
            };

            // Логотип
            var logoPanel = new Panel
            {
                Height = 100,
                Dock = DockStyle.Top,
                BackColor = isDarkTheme ? Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120)
            };

            sideMenu.Controls.Add(logoPanel);

            int buttonIndex = 0;


            if (userRole == "Admin")
            {
                AddMenuButton("🚗 АВТОМОБИЛИ", buttonIndex++, () => OpenForm(new CarsForm()));
                AddMenuButton("👥 КЛИЕНТЫ", buttonIndex++, () => OpenForm(new CustomersForm()));
                AddMenuButton("💰 ПРОДАЖИ", buttonIndex++, () => OpenForm(new SalesForm()));
                AddMenuButton("🔑 ТЕСТ-ДРАЙВЫ", buttonIndex++, () => OpenForm(new TestDrivesForm()));
                AddMenuButton("📊 ОТЧЕТЫ", buttonIndex++, () => OpenForm(new ReportsForm()));
                AddMenuButton("👤 СОТРУДНИКИ", buttonIndex++, () => OpenForm(new EmployeesForm()));
                AddMenuButton("📋 ЖУРНАЛ", buttonIndex++, () => OpenForm(new LogsForm()));
                AddMenuButton("⚙ ЗАПРОСЫ", buttonIndex++, () => OpenForm(new AdminForm()));
                AddMenuButton("💾 БЭКАП", buttonIndex++, () => OpenForm(new BackupForm()));
                AddMenuButton("💰 ПЛАТЕЖИ", buttonIndex++, () => OpenForm(new PaymentsForm()));
                AddMenuButton("📄 СТРАХОВКИ", buttonIndex++, () => OpenForm(new InsuranceForm()));
                AddMenuButton("📝 КОНТРАКТЫ", buttonIndex++, () => OpenForm(new ServiceContractsForm()));
            }

            // ===== МЕНЕДЖЕР =====
            if (userRole == "Manager")
            {
                AddMenuButton("🚗 АВТОМОБИЛИ", buttonIndex++, () => OpenForm(new CarsForm()));
                AddMenuButton("👥 КЛИЕНТЫ", buttonIndex++, () => OpenForm(new CustomersForm()));
                AddMenuButton("💰 ПРОДАЖИ", buttonIndex++, () => OpenForm(new SalesForm()));
                AddMenuButton("📊 ОТЧЕТЫ", buttonIndex++, () => OpenForm(new ReportsForm()));
            }

            // ===== ПРОДАВЕЦ =====
            if (userRole == "SalesPerson")
            {
                AddMenuButton("👥 КЛИЕНТЫ", buttonIndex++, () => OpenForm(new CustomersForm()));
                AddMenuButton("💰 ПРОДАЖИ", buttonIndex++, () => OpenForm(new SalesForm()));
                AddMenuButton("🔑 ТЕСТ-ДРАЙВЫ", buttonIndex++, () => OpenForm(new TestDrivesForm()));
                AddMenuButton("📄 СТРАХОВКИ", buttonIndex++, () => OpenForm(new InsuranceForm()));
            }

            // ===== БУХГАЛТЕР =====
            else if (userRole == "Accountant")
            {
                AddMenuButton("💰 ПЛАТЕЖИ", buttonIndex++, () => OpenForm(new PaymentsForm()));
                AddMenuButton("📊 ОТЧЕТЫ", buttonIndex++, () => OpenForm(new ReportsForm()));
            }

            // Кнопка смены темы
            btnTheme = new MaterialButton
            {
                Text = isDarkTheme ? "☀️ СВЕТЛАЯ" : "🌙 ТЕМНАЯ",
                Location = new Point(20, 650),
                Size = new Size(180, 40),
                Type = MaterialButton.MaterialButtonType.Outlined
            };
            btnTheme.Click += (s, e) => ToggleTheme();
            sideMenu.Controls.Add(btnTheme);

            // Кнопка выхода
            var btnLogout = new MaterialButton
            {
                Text = "🚪 ВЫХОД",
                Location = new Point(20, 695),
                Size = new Size(180, 40),
                Type = MaterialButton.MaterialButtonType.Text
            };
            btnLogout.Click += (s, e) => Logout();
            sideMenu.Controls.Add(btnLogout);

            // Добавляем панели на форму
            this.Controls.Add(contentPanel);
            this.Controls.Add(sideMenu);

            // Убеждаемся, что contentPanel видна
            contentPanel.BringToFront();
        }

        private void AddMenuButton(string text, int index, Action clickAction)
        {
            var btn = new MaterialButton
            {
                Text = text,
                Location = new Point(20, 110 + index * 45),
                Size = new Size(180, 40),
                Type = MaterialButton.MaterialButtonType.Text,
                DrawShadows = false
            };

            btn.Click += (s, e) => {
                clickAction();
            };

            sideMenu.Controls.Add(btn);
        }

        protected void OpenForm(Form form)
        {
            if (contentPanel == null)
            {
                MessageBox.Show("contentPanel = null", "Ошибка");
                return;
            }

            try
            {
                // Очищаем контентную панель
                contentPanel.Controls.Clear();

                // Настраиваем форму
                form.TopLevel = false;
                form.FormBorderStyle = FormBorderStyle.None;
                form.Dock = DockStyle.Fill;
                form.BackColor = contentPanel.BackColor;

                // Добавляем форму в контентную панель
                contentPanel.Controls.Add(form);

                // Показываем форму
                form.Show();
                form.BringToFront();

                // Обновляем
                contentPanel.Invalidate();
                form.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка открытия формы: {ex.Message}", "Ошибка");
            }
        }

        protected void ToggleTheme()
        {
            isDarkTheme = !isDarkTheme;

            try
            {
                Properties.Settings.Default.IsDarkTheme = isDarkTheme;
                Properties.Settings.Default.Save();
            }
            catch { }

            ApplyTheme();

            if (contentPanel.Controls.Count > 0 && contentPanel.Controls[0] is Form currentForm)
            {
                Type formType = currentForm.GetType();
                OpenForm((Form)Activator.CreateInstance(formType));
            }
        }

        protected void Logout()
        {
            var result = MessageBox.Show("Вы уверены, что хотите выйти?", "Выход",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }

    public class WelcomeForm : Form
    {
        public WelcomeForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.FormBorderStyle = FormBorderStyle.None;

            var lblWelcome = new Label
            {
                Text = "ДОБРО ПОЖАЛОВАТЬ В СИСТЕМУ",
                Font = new Font("Century Gothic", 24, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(200, 200),
                Size = new Size(800, 50),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var lblSubtitle = new Label
            {
                Text = "АВТОСАЛОН",
                Font = new Font("Century Gothic", 16),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.White : Color.Black,
                Location = new Point(200, 270),
                Size = new Size(800, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            this.Controls.Add(lblWelcome);
            this.Controls.Add(lblSubtitle);
        }
    }
}