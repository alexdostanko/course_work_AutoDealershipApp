﻿using AutoDealershipApp.Database;
using AutoDealershipApp.Helpers;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AutoDealershipApp.Forms
{
    public partial class AdminForm : Form
    {
        private DataGridView dataGridView;
        private TextBox txtQuery;
        private ListBox listQueries;

        public AdminForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
        }

        private void CreateInterface()
        {
            // Левая панель с готовыми запросами
            var leftPanel = new Panel
            {
                Location = new Point(10, 10),
                Size = new Size(280, 600),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240)
            };

            var lblQueries = new Label
            {
                Text = "ГОТОВЫЕ ЗАПРОСЫ",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(10, 10),
                Size = new Size(260, 20)
            };

            listQueries = new ListBox
            {
                Location = new Point(10, 35),
                Size = new Size(260, 450),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(50, 50, 50) : Color.FromArgb(255, 255, 255),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.White : Color.Black,
                BorderStyle = BorderStyle.None
            };

            listQueries.Items.AddRange(new string[] {
                "1. Топ-10 продаваемых моделей",
                "2. Эффективность сотрудников",
                "3. Анализ клиентов",
                "4. Отчет по складу",
                "5. Сравнение продаж по месяцам",
                "6. Статистика тест-драйвов",
                "7. Анализ методов оплаты",
                "8. Оборачиваемость авто",
                "9. Региональный анализ",
                "10. Прогноз спроса"
            });

            var btnLoadQuery = new Button
            {
                Text = "ЗАГРУЗИТЬ",
                Location = new Point(10, 500),
                Size = new Size(120, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            leftPanel.Controls.AddRange(new Control[] { lblQueries, listQueries, btnLoadQuery });

            // Правая панель - редактор запросов
            txtQuery = new TextBox
            {
                Location = new Point(300, 10),
                Size = new Size(960, 150),
                Multiline = true,
                ScrollBars = ScrollBars.Both,
                Font = new Font("Consolas", 10),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(30, 30, 30) : Color.FromArgb(255, 255, 255),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                BorderStyle = BorderStyle.FixedSingle,
                Text = "-- Введите SQL запрос здесь..."
            };

            var btnExecute = new Button
            {
                Text = "ВЫПОЛНИТЬ",
                Location = new Point(300, 170),
                Size = new Size(150, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            var btnExport = new Button
            {
                Text = "ЭКСПОРТ В EXCEL",
                Location = new Point(460, 170),
                Size = new Size(150, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.White : Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            var btnClear = new Button
            {
                Text = "ОЧИСТИТЬ",
                Location = new Point(620, 170),
                Size = new Size(100, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.White : Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            var lblResult = new Label
            {
                Text = "РЕЗУЛЬТАТ ЗАПРОСА:",
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(300, 220),
                Size = new Size(200, 20)
            };

            dataGridView = new DataGridView
            {
                Location = new Point(300, 245),
                Size = new Size(960, 380),
                BackgroundColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(30, 30, 30) : Color.FromArgb(255, 255, 255),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.White : Color.Black,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                RowHeadersVisible = false
            };

            dataGridView.DefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(30, 30, 30) : Color.FromArgb(255, 255, 255);
            dataGridView.DefaultCellStyle.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridView.EnableHeadersVisualStyles = false;

            btnLoadQuery.Click += (s, e) =>
            {
                if (listQueries.SelectedIndex >= 0)
                {
                    txtQuery.Text = GetQueryByIndex(listQueries.SelectedIndex + 1);
                }
            };

            btnExecute.Click += ExecuteQuery;
            btnExport.Click += ExportToExcel;
            btnClear.Click += (s, e) =>
            {
                txtQuery.Clear();
                dataGridView.DataSource = null;
                dataGridView.Columns.Clear();
            };

            this.Controls.Add(leftPanel);
            this.Controls.Add(txtQuery);
            this.Controls.Add(btnExecute);
            this.Controls.Add(btnExport);
            this.Controls.Add(btnClear);
            this.Controls.Add(lblResult);
            this.Controls.Add(dataGridView);
        }

        private void ExecuteQuery(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtQuery.Text))
                {
                    MessageBox.Show("Введите запрос!", "Предупреждение");
                    return;
                }

                var dt = DatabaseHelper.ExecuteQuery(txtQuery.Text);

                dataGridView.DataSource = null;
                dataGridView.Columns.Clear();

                if (dt == null || dt.Rows.Count == 0)
                {
                    dataGridView.DataSource = dt;
                    return;
                }

                dataGridView.DataSource = dt;
                dataGridView.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                foreach (DataGridViewColumn column in dataGridView.Columns)
                {
                    column.MinimumWidth = 80;
                }

                try
                {
                    string queryLog = txtQuery.Text.Length > 500 ? txtQuery.Text.Substring(0, 500) : txtQuery.Text;
                    DatabaseHelper.ExecuteNonQuery(
                        "INSERT INTO Logs (ActionType, TableName, NewValue, ActionDate) VALUES ('EXECUTE_QUERY', 'ADMIN', @query, GETDATE())",
                        new[] { new SqlParameter("@query", queryLog) });
                }
                catch { }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка выполнения запроса:\n{ex.Message}", "Ошибка");
            }
        }

        private void ExportToExcel(object sender, EventArgs e)
        {
            if (dataGridView.DataSource != null && dataGridView.Rows.Count > 0)
            {
                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Excel Files|*.xlsx",
                    FileName = $"QueryResult_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                };

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    ExportHelper.ExportToExcel((DataTable)dataGridView.DataSource, sfd.FileName);
                    MessageBox.Show($"Результат сохранен в:\n{sfd.FileName}", "Успех");
                }
            }
            else
            {
                MessageBox.Show("Нет данных для экспорта!", "Предупреждение");
            }
        }

        private string GetQueryByIndex(int index)
        {
            switch (index)
            {
                case 1: return @"SELECT TOP 10 b.BrandName AS 'Марка', m.ModelName AS 'Модель', COUNT(s.SaleID) AS 'Продажи', ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка' FROM Sales s INNER JOIN Cars c ON s.CarID = c.CarID INNER JOIN CarModels m ON c.ModelID = m.ModelID INNER JOIN CarBrands b ON m.BrandID = b.BrandID GROUP BY b.BrandName, m.ModelName ORDER BY COUNT(s.SaleID) DESC";
                case 2: return @"SELECT e.LastName + ' ' + e.FirstName AS 'Сотрудник', e.Position AS 'Должность', ISNULL(COUNT(s.SaleID), 0) AS 'Продажи', ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка' FROM Employees e LEFT JOIN Sales s ON e.EmployeeID = s.EmployeeID GROUP BY e.LastName, e.FirstName, e.Position ORDER BY Выручка DESC";
                case 3: return @"SELECT c.LastName + ' ' + c.FirstName + ISNULL(' ' + c.MiddleName, '') AS 'Клиент', c.Phone AS 'Телефон', c.Email AS 'Email', ISNULL(COUNT(s.SaleID), 0) AS 'Покупок', ISNULL(SUM(s.FinalPrice), 0) AS 'Потрачено', CASE WHEN MAX(s.SaleDate) IS NOT NULL THEN CONVERT(NVARCHAR(20), MAX(s.SaleDate), 104) ELSE 'Нет покупок' END AS 'Последняя покупка' FROM Customers c LEFT JOIN Sales s ON c.CustomerID = s.CustomerID GROUP BY c.LastName, c.FirstName, c.MiddleName, c.Phone, c.Email ORDER BY Потрачено DESC";
                case 4: return @"SELECT b.BrandName AS 'Марка', m.ModelName AS 'Модель', COUNT(c.CarID) AS 'Всего', SUM(CASE WHEN c.Status = 'В наличии' THEN 1 ELSE 0 END) AS 'В наличии', SUM(CASE WHEN c.Status = 'Продан' THEN 1 ELSE 0 END) AS 'Продано', SUM(CASE WHEN c.Status = 'Зарезервирован' THEN 1 ELSE 0 END) AS 'Зарезервировано' FROM CarBrands b LEFT JOIN CarModels m ON b.BrandID = m.BrandID LEFT JOIN Cars c ON m.ModelID = c.ModelID GROUP BY b.BrandName, m.ModelName ORDER BY b.BrandName, m.ModelName";
                case 5: return @"SELECT YEAR(s.SaleDate) AS 'Год', MONTH(s.SaleDate) AS 'Месяц', DATENAME(MONTH, s.SaleDate) AS 'Название месяца', COUNT(s.SaleID) AS 'Продажи', ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка' FROM Sales s WHERE s.SaleDate IS NOT NULL GROUP BY YEAR(s.SaleDate), MONTH(s.SaleDate), DATENAME(MONTH, s.SaleDate) ORDER BY Год DESC, Месяц DESC";
                case 6: return @"SELECT e.LastName + ' ' + e.FirstName AS 'Менеджер', COUNT(td.TestDriveID) AS 'Тест-драйвы', SUM(CASE WHEN td.Status = 'Проведен' THEN 1 ELSE 0 END) AS 'Проведено', SUM(CASE WHEN td.Status = 'Запланирован' THEN 1 ELSE 0 END) AS 'Запланировано' FROM Employees e LEFT JOIN TestDrives td ON e.EmployeeID = td.EmployeeID GROUP BY e.LastName, e.FirstName ORDER BY 'Тест-драйвы' DESC";
                case 7: return @"SELECT ISNULL(s.PaymentMethod, 'Не указан') AS 'Метод оплаты', COUNT(s.SaleID) AS 'Количество', ISNULL(SUM(s.FinalPrice), 0) AS 'Сумма', ISNULL(AVG(s.FinalPrice), 0) AS 'Средний чек' FROM Sales s GROUP BY s.PaymentMethod ORDER BY Сумма DESC";
                case 8: return @"SELECT b.BrandName AS 'Марка', m.ModelName AS 'Модель', c.VIN, CONVERT(NVARCHAR(20), c.DateAdded, 104) AS 'Дата поступления', CASE WHEN s.SaleID IS NOT NULL THEN CONVERT(NVARCHAR(20), s.SaleDate, 104) ELSE 'Не продана' END AS 'Дата продажи', DATEDIFF(DAY, c.DateAdded, ISNULL(s.SaleDate, GETDATE())) AS 'Дней в наличии' FROM Cars c INNER JOIN CarModels m ON c.ModelID = m.ModelID INNER JOIN CarBrands b ON m.BrandID = b.BrandID LEFT JOIN Sales s ON c.CarID = s.CarID ORDER BY 'Дней в наличии' DESC";
                case 9: return @"SELECT ISNULL(LEFT(c.Address, CHARINDEX(',', c.Address + ',') - 1), 'Неизвестно') AS 'Город', COUNT(DISTINCT c.CustomerID) AS 'Клиентов', COUNT(s.SaleID) AS 'Продажи', ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка' FROM Customers c LEFT JOIN Sales s ON c.CustomerID = s.CustomerID GROUP BY LEFT(c.Address, CHARINDEX(',', c.Address + ',') - 1) ORDER BY Выручка DESC";
                case 10: return @"SELECT CAST(s.SaleDate AS DATE) AS 'Дата', COUNT(s.SaleID) AS 'Продажи', ISNULL(SUM(s.FinalPrice), 0) AS 'Выручка' FROM Sales s WHERE s.SaleDate IS NOT NULL GROUP BY CAST(s.SaleDate AS DATE) ORDER BY Дата DESC";
                default: return "-- Выберите запрос из списка";
            }
        }
    }
}