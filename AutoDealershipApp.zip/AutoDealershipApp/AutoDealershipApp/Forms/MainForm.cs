﻿using System;

namespace AutoDealershipApp
{
    public partial class MainForm : BaseForm
    {
        public MainForm()
        {
            this.Text = "АВТОСАЛОН";
            this.WindowState = FormWindowState.Maximized;
            // WelcomeForm открывается автоматически в BaseForm
        }
    }
}