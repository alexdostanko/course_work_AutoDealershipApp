﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using AutoDealershipApp.Database;
using System.Data.SqlClient;

namespace AutoDealershipApp.Forms
{
    public partial class ServiceContractsForm : Form
    {
        private DataGridView dataGridView;
        private TextBox txtSearch;
        private Button btnAdd, btnEdit, btnDelete;
        private int selectedContractId = -1;

        public ServiceContractsForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadContracts();
        }

        private void CreateInterface()
        {
            // Заголовок
            var lblTitle = new Label
            {
                Text = "📝 СЕРВИСНЫЕ КОНТРАКТЫ",
                Font = new Font("Century Gothic", 18, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(20, 10),
                Size = new Size(500, 40)
            };
            this.Controls.Add(lblTitle);

            // Панель поиска
            var topPanel = new Panel
            {
                Location = new Point(0, 60),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            txtSearch = new TextBox
            {
                Location = new Point(10, 15),
                Size = new Size(300, 30),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtSearch.TextChanged += (s, e) => LoadContracts(txtSearch.Text);

            var lblSearch = new Label
            {
                Text = "🔍 Поиск:",
                ForeColor = this.ForeColor,
                Location = new Point(320, 18),
                AutoSize = true
            };

            btnAdd = new Button
            {
                Text = "+ НОВЫЙ КОНТРАКТ",
                Location = new Point(700, 10),
                Size = new Size(160, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnAdd.Click += (s, e) => ShowContractDialog(null);

            btnEdit = new Button
            {
                Text = "✏ РЕДАКТИРОВАТЬ",
                Location = new Point(870, 10),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnEdit.Click += (s, e) => EditContract();

            btnDelete = new Button
            {
                Text = "🗑 УДАЛИТЬ",
                Location = new Point(1020, 10),
                Size = new Size(100, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.Click += (s, e) => DeleteContract();

            topPanel.Controls.AddRange(new Control[] { txtSearch, lblSearch, btnAdd, btnEdit, btnDelete });
            this.Controls.Add(topPanel);

            // Таблица контрактов
            dataGridView = new DataGridView
            {
                Location = new Point(0, 120),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 120),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.EnableHeadersVisualStyles = false;

            dataGridView.SelectionChanged += (s, e) =>
            {
                if (dataGridView.SelectedRows.Count > 0)
                {
                    selectedContractId = Convert.ToInt32(dataGridView.SelectedRows[0].Cells["ID"].Value);
                }
            };

            this.Controls.Add(dataGridView);

            this.Resize += (s, e) =>
            {
                topPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 120);
            };
        }

        private void LoadContracts(string searchText = "")
        {
            string query = @"
                SELECT 
                    c.ContractID AS 'ID',
                    c.ContractNumber AS 'Номер контракта',
                    b.BrandName + ' ' + m.ModelName AS 'Автомобиль',
                    cust.LastName + ' ' + cust.FirstName AS 'Клиент',
                    c.ContractType AS 'Тип',
                    FORMAT(c.Price, 'N0') + ' ₽' AS 'Стоимость',
                    CONVERT(NVARCHAR(20), c.StartDate, 104) AS 'С',
                    CONVERT(NVARCHAR(20), c.EndDate, 104) AS 'По'
                FROM ServiceContracts c
                JOIN Sales s ON c.SaleID = s.SaleID
                JOIN Cars car ON s.CarID = car.CarID
                JOIN CarModels m ON car.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                JOIN Customers cust ON s.CustomerID = cust.CustomerID
                WHERE c.ContractNumber LIKE @search OR b.BrandName LIKE @search OR cust.LastName LIKE @search
                ORDER BY c.EndDate";

            var dt = DatabaseHelper.ExecuteQuery(query, new[] {
                new SqlParameter("@search", $"%{searchText}%")
            });

            dataGridView.DataSource = dt;
            if (dataGridView.Columns["ID"] != null)
                dataGridView.Columns["ID"].Visible = false;
        }

        private void ShowContractDialog(DataGridViewRow existingRow)
        {
            var dialog = new Form
            {
                Text = existingRow == null ? "Новый сервисный контракт" : "Редактирование контракта",
                Size = new Size(500, 450),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            // Загружаем продажи без контрактов
            var sales = DatabaseHelper.ExecuteQuery(@"
                SELECT s.SaleID, 
                       b.BrandName + ' ' + m.ModelName + ' - ' + cust.LastName + ' ' + FORMAT(s.SaleDate, 'dd.MM.yyyy') AS SaleInfo
                FROM Sales s
                JOIN Cars c ON s.CarID = c.CarID
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                JOIN Customers cust ON s.CustomerID = cust.CustomerID
                LEFT JOIN ServiceContracts sc ON s.SaleID = sc.SaleID
                WHERE sc.ContractID IS NULL");

            var lblSale = new Label { Text = "Продажа:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbSale = new ComboBox
            {
                Location = new Point(130, 20),
                Size = new Size(330, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = sales,
                DisplayMember = "SaleInfo",
                ValueMember = "SaleID"
            };

            var lblNumber = new Label { Text = "Номер контракта:", Location = new Point(20, 60), Size = new Size(120, 25), ForeColor = this.ForeColor };
            var txtNumber = new TextBox
            {
                Location = new Point(140, 60),
                Size = new Size(200, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                Text = "SC-" + DateTime.Now.ToString("yyyyMMdd-") + new Random().Next(1000, 9999)
            };

            var lblType = new Label { Text = "Тип контракта:", Location = new Point(20, 100), Size = new Size(120, 25), ForeColor = this.ForeColor };
            var cmbType = new ComboBox
            {
                Location = new Point(140, 100),
                Size = new Size(200, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbType.Items.AddRange(new[] { "Стандартное ТО", "Расширенная гарантия", "Премиум обслуживание", "Продленная гарантия" });

            var lblPrice = new Label { Text = "Стоимость:", Location = new Point(20, 140), Size = new Size(120, 25), ForeColor = this.ForeColor };
            var txtPrice = new TextBox
            {
                Location = new Point(140, 140),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                Text = "0"
            };

            var lblStart = new Label { Text = "Дата начала:", Location = new Point(20, 180), Size = new Size(120, 25), ForeColor = this.ForeColor };
            var dtpStart = new DateTimePicker
            {
                Location = new Point(140, 180),
                Size = new Size(150, 25),
                Value = DateTime.Now,
                Format = DateTimePickerFormat.Short
            };

            var lblEnd = new Label { Text = "Дата окончания:", Location = new Point(20, 220), Size = new Size(120, 25), ForeColor = this.ForeColor };
            var dtpEnd = new DateTimePicker
            {
                Location = new Point(140, 220),
                Size = new Size(150, 25),
                Value = DateTime.Now.AddYears(2),
                Format = DateTimePickerFormat.Short
            };

            var btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Location = new Point(140, 300),
                Size = new Size(200, 40),
                BackColor = btnAdd.BackColor,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            // Заполняем при редактировании
            if (existingRow != null)
            {
                cmbSale.Enabled = false;
                txtNumber.Text = existingRow.Cells["Номер контракта"].Value.ToString();
                cmbType.Text = existingRow.Cells["Тип"].Value.ToString();
                txtPrice.Text = existingRow.Cells["Стоимость"].Value.ToString().Replace(" ₽", "").Replace(" ", "");
                // Даты нужно получить отдельным запросом
            }

            btnSave.Click += (s, e) =>
            {
                if (cmbSale.SelectedValue == null || string.IsNullOrWhiteSpace(txtNumber.Text))
                {
                    MessageBox.Show("Заполните все поля!");
                    return;
                }

                try
                {
                    if (existingRow == null)
                    {
                        string query = @"
                            INSERT INTO ServiceContracts (SaleID, ContractNumber, ContractType, Price, StartDate, EndDate)
                            VALUES (@sale, @num, @type, @price, @start, @end)";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@sale", cmbSale.SelectedValue),
                            new SqlParameter("@num", txtNumber.Text),
                            new SqlParameter("@type", cmbType.Text),
                            new SqlParameter("@price", decimal.Parse(txtPrice.Text)),
                            new SqlParameter("@start", dtpStart.Value),
                            new SqlParameter("@end", dtpEnd.Value)
                        });
                    }
                    else
                    {
                        int id = Convert.ToInt32(existingRow.Cells["ID"].Value);
                        string query = @"
                            UPDATE ServiceContracts 
                            SET ContractNumber=@num, ContractType=@type, Price=@price,
                                StartDate=@start, EndDate=@end
                            WHERE ContractID=@id";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@id", id),
                            new SqlParameter("@num", txtNumber.Text),
                            new SqlParameter("@type", cmbType.Text),
                            new SqlParameter("@price", decimal.Parse(txtPrice.Text)),
                            new SqlParameter("@start", dtpStart.Value),
                            new SqlParameter("@end", dtpEnd.Value)
                        });
                    }

                    MessageBox.Show("Сервисный контракт сохранен!");
                    dialog.Close();
                    LoadContracts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblSale, cmbSale, lblNumber, txtNumber, lblType, cmbType,
                lblPrice, txtPrice, lblStart, dtpStart, lblEnd, dtpEnd, btnSave
            });

            dialog.ShowDialog(this);
        }

        private void EditContract()
        {
            if (dataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите контракт для редактирования!");
                return;
            }
            ShowContractDialog(dataGridView.SelectedRows[0]);
        }

        private void DeleteContract()
        {
            if (selectedContractId == -1)
            {
                MessageBox.Show("Выберите контракт для удаления!");
                return;
            }

            var result = MessageBox.Show("Удалить сервисный контракт?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    DatabaseHelper.ExecuteNonQuery("DELETE FROM ServiceContracts WHERE ContractID = @id",
                        new[] { new SqlParameter("@id", selectedContractId) });
                    LoadContracts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
        }
    }
}