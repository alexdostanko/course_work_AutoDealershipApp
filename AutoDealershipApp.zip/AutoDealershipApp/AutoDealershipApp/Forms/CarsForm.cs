﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using AutoDealershipApp.Database;
using System.Data.SqlClient;

namespace AutoDealershipApp.Forms
{
    public partial class CarsForm : Form
    {
        private FlowLayoutPanel flowPanel;
        private TextBox txtSearch;
        private ComboBox cmbBrand;
        private ComboBox cmbStatus;
        private Dictionary<int, string> carPhotos = new Dictionary<int, string>();
        private Panel searchPanel;
        private Button btnAdd, btnEdit, btnDelete;
        private int selectedCarId = -1;

        public CarsForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;
            this.Padding = new Padding(0);

            LoadSavedPhotos();
            CreateInterface();
            LoadCars();
        }

        private void LoadSavedPhotos()
        {
            string photosDir = Path.Combine(Application.StartupPath, "CarPhotos");
            if (Directory.Exists(photosDir))
            {
                foreach (string file in Directory.GetFiles(photosDir, "car_*.jpg"))
                {
                    string fileName = Path.GetFileNameWithoutExtension(file);
                    string idStr = fileName.Replace("car_", "");
                    if (int.TryParse(idStr, out int carId))
                    {
                        carPhotos[carId] = file;
                    }
                }
            }
        }

        private void CreateInterface()
        {
            // Панель поиска и кнопок
            searchPanel = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(this.ClientSize.Width, 100),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            // Поиск
            txtSearch = new TextBox
            {
                Location = new Point(10, 15),
                Size = new Size(300, 30),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtSearch.TextChanged += (s, e) => LoadCars();

            var lblSearch = new Label
            {
                Text = "🔍 Поиск:",
                ForeColor = this.ForeColor,
                Location = new Point(320, 18),
                AutoSize = true
            };

            // Фильтры
            cmbBrand = new ComboBox
            {
                Location = new Point(400, 15),
                Size = new Size(150, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            cmbStatus = new ComboBox
            {
                Location = new Point(560, 15),
                Size = new Size(150, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbStatus.Items.AddRange(new object[] { "Все", "В наличии", "Продан", "Зарезервирован" });
            cmbStatus.SelectedIndex = 0;

            LoadBrands();

            cmbBrand.SelectedIndexChanged += (s, e) => LoadCars();
            cmbStatus.SelectedIndexChanged += (s, e) => LoadCars();

            // Кнопки управления
            btnAdd = new Button
            {
                Text = "+ ДОБАВИТЬ АВТО",
                Location = new Point(800, 10),
                Size = new Size(140, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnAdd.Click += (s, e) => ShowCarDialog(null);

            btnEdit = new Button
            {
                Text = "✏ РЕДАКТИРОВАТЬ",
                Location = new Point(950, 10),
                Size = new Size(140, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnEdit.Click += (s, e) => EditCar();

            btnDelete = new Button
            {
                Text = "🗑 УДАЛИТЬ",
                Location = new Point(1100, 10),
                Size = new Size(100, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.Click += (s, e) => DeleteCar();

            searchPanel.Controls.AddRange(new Control[] {
                txtSearch, lblSearch, cmbBrand, cmbStatus,
                btnAdd, btnEdit, btnDelete
            });

            // FlowLayoutPanel для карточек
            flowPanel = new FlowLayoutPanel
            {
                Location = new Point(0, 100),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 100),
                AutoScroll = true,
                BackColor = this.BackColor,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            this.Resize += (s, e) =>
            {
                searchPanel.Width = this.ClientSize.Width;
                flowPanel.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 100);
            };

            this.Controls.Add(searchPanel);
            this.Controls.Add(flowPanel);
        }

        private void LoadBrands()
        {
            var dt = DatabaseHelper.ExecuteQuery("SELECT BrandID, BrandName FROM CarBrands ORDER BY BrandName");

            DataTable newDt = new DataTable();
            newDt.Columns.Add("BrandID", typeof(int));
            newDt.Columns.Add("BrandName", typeof(string));

            DataRow allRow = newDt.NewRow();
            allRow["BrandID"] = 0;
            allRow["BrandName"] = "Все марки";
            newDt.Rows.Add(allRow);

            foreach (DataRow row in dt.Rows)
            {
                newDt.Rows.Add(row["BrandID"], row["BrandName"]);
            }

            cmbBrand.DataSource = newDt;
            cmbBrand.DisplayMember = "BrandName";
            cmbBrand.ValueMember = "BrandID";
        }

        private void LoadCars()
        {
            flowPanel.Controls.Clear();

            string query = @"
                SELECT c.CarID, c.VIN, c.Year, c.Color, c.Price, c.Mileage, c.Status,
                       b.BrandName, m.ModelName, m.BodyType, m.EngineType, m.Transmission,
                       m.ModelID, b.BrandID
                FROM Cars c
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                WHERE (c.VIN LIKE @search OR b.BrandName LIKE @search OR m.ModelName LIKE @search)
                  AND (@brandID = 0 OR b.BrandID = @brandID)
                  AND (@status = 'Все' OR c.Status = @status)";

            var parameters = new[]
            {
                new SqlParameter("@search", $"%{txtSearch.Text}%"),
                new SqlParameter("@brandID", cmbBrand.SelectedValue ?? 0),
                new SqlParameter("@status", cmbStatus.Text)
            };

            var dt = DatabaseHelper.ExecuteQuery(query, parameters);

            foreach (DataRow row in dt.Rows)
            {
                flowPanel.Controls.Add(CreateCarCard(row));
            }

            if (flowPanel.Controls.Count == 0)
            {
                var lblEmpty = new Label
                {
                    Text = "Автомобили не найдены",
                    Font = new Font("Segoe UI", 16, FontStyle.Bold),
                    ForeColor = Color.Gray,
                    Location = new Point(500, 200),
                    Size = new Size(300, 50),
                    TextAlign = ContentAlignment.MiddleCenter
                };
                flowPanel.Controls.Add(lblEmpty);
            }
        }

        private Panel CreateCarCard(DataRow car)
        {
            int carId = Convert.ToInt32(car["CarID"]);

            var card = new Panel
            {
                Size = new Size(280, 460),
                Margin = new Padding(10),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(45, 45, 45) : Color.FromArgb(240, 240, 240),
                BorderStyle = BorderStyle.FixedSingle,
                AllowDrop = true,
                Tag = carId
            };

            var lblTitle = new Label
            {
                Text = $"{car["BrandName"]} {car["ModelName"]}",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(10, 10),
                Size = new Size(260, 25),
                TextAlign = ContentAlignment.MiddleLeft
            };

            var picBox = new PictureBox
            {
                Location = new Point(10, 40),
                Size = new Size(260, 140),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(220, 220, 220),
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom,
                AllowDrop = true
            };

            if (carPhotos.ContainsKey(carId) && File.Exists(carPhotos[carId]))
            {
                try
                {
                    picBox.Image = Image.FromFile(carPhotos[carId]);
                }
                catch
                {
                    DrawNoPhoto(picBox);
                }
            }
            else
            {
                DrawNoPhoto(picBox);
            }

            picBox.DragEnter += (s, e) =>
            {
                if (e.Data.GetDataPresent(DataFormats.FileDrop))
                {
                    e.Effect = DragDropEffects.Copy;
                }
            };

            picBox.DragDrop += (s, e) =>
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0)
                {
                    string file = files[0];
                    string ext = Path.GetExtension(file).ToLower();

                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".bmp")
                    {
                        try
                        {
                            string photosDir = Path.Combine(Application.StartupPath, "CarPhotos");
                            if (!Directory.Exists(photosDir))
                                Directory.CreateDirectory(photosDir);

                            string newFile = Path.Combine(photosDir, $"car_{carId}.jpg");

                            using (var img = Image.FromFile(file))
                            {
                                img.Save(newFile, System.Drawing.Imaging.ImageFormat.Jpeg);
                            }

                            picBox.Image?.Dispose();
                            picBox.Image = Image.FromFile(newFile);
                            carPhotos[carId] = newFile;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Ошибка загрузки фото: {ex.Message}");
                        }
                    }
                }
            };

            var lblDrag = new Label
            {
                Text = "📷 Перетащите фото сюда",
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.Gray : Color.DarkGray,
                Location = new Point(50, 185),
                Size = new Size(180, 20),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 8)
            };

            var lblYear = new Label
            {
                Text = $"Год: {car["Year"]}",
                ForeColor = this.ForeColor,
                Location = new Point(10, 210),
                Size = new Size(120, 20)
            };

            var lblColor = new Label
            {
                Text = $"Цвет: {car["Color"]}",
                ForeColor = this.ForeColor,
                Location = new Point(10, 230),
                Size = new Size(120, 20)
            };

            decimal price = car["Price"] == DBNull.Value ? 0 : Convert.ToDecimal(car["Price"]);
            var lblPrice = new Label
            {
                Text = $"Цена: {price:N0} ₽",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(10, 255),
                Size = new Size(260, 25)
            };

            var lblStatus = new Label
            {
                Text = $"Статус: {car["Status"]}",
                ForeColor = GetStatusColor(car["Status"].ToString()),
                Location = new Point(10, 280),
                Size = new Size(260, 20)
            };

            var lblEngine = new Label
            {
                Text = $"{car["EngineType"]}, {car["Transmission"]}",
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.LightGray : Color.DimGray,
                Location = new Point(10, 300),
                Size = new Size(260, 20)
            };

            var btnDetails = new Button
            {
                Text = "ПОДРОБНЕЕ",
                Location = new Point(10, 330),
                Size = new Size(120, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnDetails.Click += (s, e) => ShowCarDetails(car);

            var btnEditCard = new Button
            {
                Text = "✏",
                Location = new Point(140, 330),
                Size = new Size(50, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnEditCard.Click += (s, e) => EditCarById(carId);

            var btnDeleteCard = new Button
            {
                Text = "🗑",
                Location = new Point(200, 330),
                Size = new Size(50, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnDeleteCard.Click += (s, e) => DeleteCarById(carId);

            card.Controls.AddRange(new Control[] {
                lblTitle, picBox, lblDrag, lblYear, lblColor, lblPrice,
                lblStatus, lblEngine, btnDetails, btnEditCard, btnDeleteCard
            });

            return card;
        }

        private void DrawNoPhoto(PictureBox picBox)
        {
            picBox.Paint += (s, e) =>
            {
                e.Graphics.Clear(picBox.BackColor);
                using (Font font = new Font("Segoe UI", 10, FontStyle.Bold))
                using (Brush brush = new SolidBrush(Color.Gray))
                {
                    string text = "🚗 НЕТ ФОТО";
                    SizeF textSize = e.Graphics.MeasureString(text, font);
                    float x = (picBox.Width - textSize.Width) / 2;
                    float y = (picBox.Height - textSize.Height) / 2;
                    e.Graphics.DrawString(text, font, brush, x, y);
                }
            };
        }

        private Color GetStatusColor(string status)
        {
            return status switch
            {
                "В наличии" => Color.FromArgb(0, 255, 0),
                "Продан" => Color.FromArgb(255, 100, 100),
                "Зарезервирован" => Color.FromArgb(255, 255, 0),
                _ => this.ForeColor
            };
        }

        private void ShowCarDetails(DataRow car)
        {
            decimal price = car["Price"] == DBNull.Value ? 0 : Convert.ToDecimal(car["Price"]);

            MessageBox.Show(
                $"Марка: {car["BrandName"]}\n" +
                $"Модель: {car["ModelName"]}\n" +
                $"Год: {car["Year"]}\n" +
                $"Цвет: {car["Color"]}\n" +
                $"Цена: {price:N0} ₽\n" +
                $"Пробег: {car["Mileage"]} км\n" +
                $"VIN: {car["VIN"]}\n" +
                $"Кузов: {car["BodyType"]}\n" +
                $"Двигатель: {car["EngineType"]}\n" +
                $"КПП: {car["Transmission"]}",
                "Детали автомобиля",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void ShowCarDialog(DataRow existingCar)
        {
            var dialog = new Form
            {
                Text = existingCar == null ? "Добавление автомобиля" : "Редактирование автомобиля",
                Size = new Size(500, 550),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            // Загружаем марки и модели
            var brands = DatabaseHelper.ExecuteQuery("SELECT BrandID, BrandName FROM CarBrands ORDER BY BrandName");

            var lblBrand = new Label { Text = "Марка:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbBrandDlg = new ComboBox
            {
                Location = new Point(130, 20),
                Size = new Size(200, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = brands,
                DisplayMember = "BrandName",
                ValueMember = "BrandID"
            };

            var lblModel = new Label { Text = "Модель:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbModelDlg = new ComboBox
            {
                Location = new Point(130, 60),
                Size = new Size(200, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            // Загружаем модели при выборе марки
            cmbBrandDlg.SelectedIndexChanged += (s, e) =>
            {
                if (cmbBrandDlg.SelectedValue != null && cmbBrandDlg.SelectedValue is int)
                {
                    var models = DatabaseHelper.ExecuteQuery(
                        "SELECT ModelID, ModelName FROM CarModels WHERE BrandID = @id ORDER BY ModelName",
                        new[] { new SqlParameter("@id", cmbBrandDlg.SelectedValue) });

                    cmbModelDlg.DataSource = models;
                    cmbModelDlg.DisplayMember = "ModelName";
                    cmbModelDlg.ValueMember = "ModelID";
                }
            };

            var lblYear = new Label { Text = "Год:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var numYear = new NumericUpDown
            {
                Location = new Point(130, 100),
                Size = new Size(100, 25),
                Minimum = 1990,
                Maximum = 2025,
                Value = 2024,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var lblColor = new Label { Text = "Цвет:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtColor = new TextBox
            {
                Location = new Point(130, 140),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var lblPrice = new Label { Text = "Цена:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtPrice = new TextBox
            {
                Location = new Point(130, 180),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var lblMileage = new Label { Text = "Пробег:", Location = new Point(20, 220), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var numMileage = new NumericUpDown
            {
                Location = new Point(130, 220),
                Size = new Size(100, 25),
                Maximum = 1000000,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var lblVIN = new Label { Text = "VIN:", Location = new Point(20, 260), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtVIN = new TextBox
            {
                Location = new Point(130, 260),
                Size = new Size(250, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                MaxLength = 17
            };

            var lblStatus = new Label { Text = "Статус:", Location = new Point(20, 300), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbStatusDlg = new ComboBox
            {
                Location = new Point(130, 300),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbStatusDlg.Items.AddRange(new[] { "В наличии", "Зарезервирован", "Продан", "В пути" });

            var lblLocation = new Label { Text = "Склад:", Location = new Point(20, 340), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtLocation = new TextBox
            {
                Location = new Point(130, 340),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                Text = "Склад A1"
            };

            var btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Location = new Point(130, 400),
                Size = new Size(200, 40),
                BackColor = btnAdd.BackColor,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            // Заполняем при редактировании
            if (existingCar != null)
            {
                cmbBrandDlg.SelectedValue = existingCar["BrandID"];
                cmbModelDlg.SelectedValue = existingCar["ModelID"];
                numYear.Value = Convert.ToInt32(existingCar["Year"]);
                txtColor.Text = existingCar["Color"].ToString();
                txtPrice.Text = existingCar["Price"].ToString();
                numMileage.Value = Convert.ToInt32(existingCar["Mileage"]);
                txtVIN.Text = existingCar["VIN"].ToString();
                cmbStatusDlg.Text = existingCar["Status"].ToString();
                txtLocation.Text = existingCar["LocationWarehouse"]?.ToString() ?? "Склад A1";
            }

            btnSave.Click += (s, e) =>
            {
                if (cmbBrandDlg.SelectedValue == null || cmbModelDlg.SelectedValue == null ||
                    string.IsNullOrWhiteSpace(txtVIN.Text) || string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Заполните все обязательные поля!");
                    return;
                }

                if (txtVIN.Text.Length != 17)
                {
                    MessageBox.Show("VIN должен содержать 17 символов!");
                    return;
                }

                try
                {
                    if (existingCar == null)
                    {
                        string query = @"
                            INSERT INTO Cars (VIN, ModelID, Year, Color, Price, Mileage, Status, LocationWarehouse, DateAdded)
                            VALUES (@vin, @model, @year, @color, @price, @mileage, @status, @loc, GETDATE())";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@vin", txtVIN.Text.ToUpper()),
                            new SqlParameter("@model", cmbModelDlg.SelectedValue),
                            new SqlParameter("@year", (int)numYear.Value),
                            new SqlParameter("@color", txtColor.Text),
                            new SqlParameter("@price", decimal.Parse(txtPrice.Text)),
                            new SqlParameter("@mileage", (int)numMileage.Value),
                            new SqlParameter("@status", cmbStatusDlg.Text),
                            new SqlParameter("@loc", txtLocation.Text)
                        });
                    }
                    else
                    {
                        int id = Convert.ToInt32(existingCar["CarID"]);
                        string query = @"
                            UPDATE Cars 
                            SET VIN=@vin, ModelID=@model, Year=@year, Color=@color,
                                Price=@price, Mileage=@mileage, Status=@status, LocationWarehouse=@loc
                            WHERE CarID=@id";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@id", id),
                            new SqlParameter("@vin", txtVIN.Text.ToUpper()),
                            new SqlParameter("@model", cmbModelDlg.SelectedValue),
                            new SqlParameter("@year", (int)numYear.Value),
                            new SqlParameter("@color", txtColor.Text),
                            new SqlParameter("@price", decimal.Parse(txtPrice.Text)),
                            new SqlParameter("@mileage", (int)numMileage.Value),
                            new SqlParameter("@status", cmbStatusDlg.Text),
                            new SqlParameter("@loc", txtLocation.Text)
                        });
                    }

                    MessageBox.Show("Автомобиль сохранен!");
                    dialog.Close();
                    LoadCars();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblBrand, cmbBrandDlg, lblModel, cmbModelDlg, lblYear, numYear,
                lblColor, txtColor, lblPrice, txtPrice, lblMileage, numMileage,
                lblVIN, txtVIN, lblStatus, cmbStatusDlg, lblLocation, txtLocation, btnSave
            });

            dialog.ShowDialog(this);
        }

        private void EditCar()
        {
            if (selectedCarId == -1)
            {
                // Если не выбран через карточку, пробуем найти выбранную карточку
                foreach (Control ctrl in flowPanel.Controls)
                {
                    if (ctrl is Panel card && card.BorderStyle == BorderStyle.FixedSingle)
                    {
                        selectedCarId = Convert.ToInt32(card.Tag);
                        break;
                    }
                }
            }

            if (selectedCarId == -1)
            {
                MessageBox.Show("Выберите автомобиль для редактирования!");
                return;
            }

            // Загружаем данные автомобиля с JOIN, чтобы получить BrandID
            var dt = DatabaseHelper.ExecuteQuery(@"
        SELECT c.*, m.BrandID, m.ModelName, b.BrandName
        FROM Cars c
        JOIN CarModels m ON c.ModelID = m.ModelID
        JOIN CarBrands b ON m.BrandID = b.BrandID
        WHERE c.CarID = @id",
                new[] { new SqlParameter("@id", selectedCarId) });

            if (dt.Rows.Count > 0)
            {
                ShowCarDialog(dt.Rows[0]);
            }
        }

        private void EditCarById(int carId)
        {
            selectedCarId = carId;
            EditCar();
        }

        private void DeleteCar()
        {
            if (selectedCarId == -1)
            {
                MessageBox.Show("Выберите автомобиль для удаления!");
                return;
            }

            var result = MessageBox.Show("Удалить автомобиль?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    DatabaseHelper.ExecuteNonQuery("DELETE FROM Cars WHERE CarID = @id",
                        new[] { new SqlParameter("@id", selectedCarId) });

                    // Удаляем фото если есть
                    if (carPhotos.ContainsKey(selectedCarId))
                    {
                        try { File.Delete(carPhotos[selectedCarId]); } catch { }
                        carPhotos.Remove(selectedCarId);
                    }

                    MessageBox.Show("Автомобиль удален!");
                    LoadCars();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
        }

        private void DeleteCarById(int carId)
        {
            selectedCarId = carId;
            DeleteCar();
        }
    }
}