﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using AutoDealershipApp.Database;
using System.Data.SqlClient;

namespace AutoDealershipApp.Forms
{
    public partial class CustomersForm : Form
    {
        private DataGridView dataGridView;
        private TextBox txtSearch;
        private Button btnAdd, btnEdit, btnDelete;
        private int selectedCustomerId = -1;
        private Panel topPanel;

        public CustomersForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadCustomers();
        }

        private void CreateInterface()
        {
            // Верхняя панель с поиском и кнопками
            topPanel = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            txtSearch = new TextBox
            {
                Location = new Point(10, 15),
                Size = new Size(300, 30),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.White : Color.Black,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtSearch.TextChanged += (s, e) => LoadCustomers(txtSearch.Text);

            var lblSearch = new Label
            {
                Text = "🔍 Поиск:",
                ForeColor = this.ForeColor,
                Location = new Point(320, 18),
                AutoSize = true
            };

            btnAdd = new Button
            {
                Text = "+ ДОБАВИТЬ",
                Location = new Point(800, 10),
                Size = new Size(120, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnAdd.Click += (s, e) => ShowCustomerDialog(null);

            btnEdit = new Button
            {
                Text = "✏ РЕДАКТИРОВАТЬ",
                Location = new Point(930, 10),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnEdit.Click += (s, e) => EditCustomer();

            btnDelete = new Button
            {
                Text = "🗑 УДАЛИТЬ",
                Location = new Point(1080, 10),
                Size = new Size(100, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.Click += (s, e) => DeleteCustomer();

            topPanel.Controls.AddRange(new Control[] { txtSearch, lblSearch, btnAdd, btnEdit, btnDelete });

            // DataGridView для клиентов
            dataGridView = new DataGridView
            {
                Location = new Point(0, 60),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 60),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            // Настройка стилей DataGridView
            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridView.EnableHeadersVisualStyles = false;

            // Подписка на событие выбора строки
            dataGridView.SelectionChanged += (s, e) =>
            {
                if (dataGridView.SelectedRows.Count > 0 && dataGridView.SelectedRows[0].Cells["ID"].Value != null)
                {
                    selectedCustomerId = Convert.ToInt32(dataGridView.SelectedRows[0].Cells["ID"].Value);
                }
            };

            // Обновляем размеры при изменении размера формы
            this.Resize += (s, e) =>
            {
                topPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 60);
            };

            this.Controls.Add(topPanel);
            this.Controls.Add(dataGridView);
        }

        private void LoadCustomers(string searchText = "")
        {
            try
            {
                string query = @"
                    SELECT 
                        CustomerID AS 'ID',
                        LastName + ' ' + FirstName + ISNULL(' ' + MiddleName, '') AS 'ФИО',
                        Phone AS 'Телефон',
                        Email AS 'Email',
                        Address AS 'Адрес',
                        CASE WHEN DiscountCard = 1 THEN 'Да' ELSE 'Нет' END AS 'Дисконтная карта',
                        CONVERT(NVARCHAR(20), RegistrationDate, 104) AS 'Дата регистрации'
                    FROM Customers
                    WHERE LastName LIKE @search OR FirstName LIKE @search OR Phone LIKE @search OR Email LIKE @search
                    ORDER BY CustomerID DESC";

                var dt = DatabaseHelper.ExecuteQuery(query, new[] {
                    new SqlParameter("@search", $"%{searchText}%")
                });

                dataGridView.DataSource = dt;

                if (dataGridView.Columns["ID"] != null)
                    dataGridView.Columns["ID"].Visible = false;

                // Сброс выбранного ID
                selectedCustomerId = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки клиентов: {ex.Message}", "Ошибка");
            }
        }

        // ... остальные методы (ShowCustomerDialog, EditCustomer, DeleteCustomer) остаются без изменений ...
        private void ShowCustomerDialog(DataGridViewRow existingRow)
        {
            var dialog = new Form
            {
                Text = existingRow == null ? "Добавление клиента" : "Редактирование клиента",
                Size = new Size(450, 500),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            var lblLastName = new Label { Text = "Фамилия:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtLastName = new TextBox { Location = new Point(130, 20), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor, BorderStyle = BorderStyle.FixedSingle };

            var lblFirstName = new Label { Text = "Имя:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtFirstName = new TextBox { Location = new Point(130, 60), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor, BorderStyle = BorderStyle.FixedSingle };

            var lblMiddleName = new Label { Text = "Отчество:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtMiddleName = new TextBox { Location = new Point(130, 100), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor, BorderStyle = BorderStyle.FixedSingle };

            var lblPhone = new Label { Text = "Телефон:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtPhone = new TextBox { Location = new Point(130, 140), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor, BorderStyle = BorderStyle.FixedSingle };

            var lblEmail = new Label { Text = "Email:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtEmail = new TextBox { Location = new Point(130, 180), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor, BorderStyle = BorderStyle.FixedSingle };

            var lblAddress = new Label { Text = "Адрес:", Location = new Point(20, 220), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtAddress = new TextBox { Location = new Point(130, 220), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor, BorderStyle = BorderStyle.FixedSingle };

            var chkDiscount = new CheckBox { Text = "Дисконтная карта", Location = new Point(130, 260), Size = new Size(150, 25), ForeColor = this.ForeColor };

            var btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Location = new Point(130, 320),
                Size = new Size(180, 40),
                BackColor = btnAdd.BackColor,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            if (existingRow != null)
            {
                string fullName = existingRow.Cells["ФИО"].Value.ToString();
                string[] nameParts = fullName.Split(' ');

                txtLastName.Text = nameParts.Length > 0 ? nameParts[0] : "";
                txtFirstName.Text = nameParts.Length > 1 ? nameParts[1] : "";
                txtMiddleName.Text = nameParts.Length > 2 ? nameParts[2] : "";

                txtPhone.Text = existingRow.Cells["Телефон"].Value.ToString();
                txtEmail.Text = existingRow.Cells["Email"].Value.ToString();
                txtAddress.Text = existingRow.Cells["Адрес"].Value.ToString();
                chkDiscount.Checked = existingRow.Cells["Дисконтная карта"].Value.ToString() == "Да";
            }

            btnSave.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtFirstName.Text))
                {
                    MessageBox.Show("Заполните фамилию и имя!", "Ошибка");
                    return;
                }

                try
                {
                    if (existingRow == null)
                    {
                        string query = @"
                            INSERT INTO Customers (LastName, FirstName, MiddleName, Phone, Email, Address, DiscountCard, RegistrationDate)
                            VALUES (@ln, @fn, @mn, @phone, @email, @addr, @disc, GETDATE())";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@ln", txtLastName.Text),
                            new SqlParameter("@fn", txtFirstName.Text),
                            new SqlParameter("@mn", txtMiddleName.Text),
                            new SqlParameter("@phone", txtPhone.Text),
                            new SqlParameter("@email", txtEmail.Text),
                            new SqlParameter("@addr", txtAddress.Text),
                            new SqlParameter("@disc", chkDiscount.Checked ? 1 : 0)
                        });

                        MessageBox.Show("Клиент успешно добавлен!", "Успех");
                    }
                    else
                    {
                        int id = Convert.ToInt32(existingRow.Cells["ID"].Value);
                        string query = @"
                            UPDATE Customers 
                            SET LastName = @ln, FirstName = @fn, MiddleName = @mn,
                                Phone = @phone, Email = @email, Address = @addr,
                                DiscountCard = @disc
                            WHERE CustomerID = @id";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@id", id),
                            new SqlParameter("@ln", txtLastName.Text),
                            new SqlParameter("@fn", txtFirstName.Text),
                            new SqlParameter("@mn", txtMiddleName.Text),
                            new SqlParameter("@phone", txtPhone.Text),
                            new SqlParameter("@email", txtEmail.Text),
                            new SqlParameter("@addr", txtAddress.Text),
                            new SqlParameter("@disc", chkDiscount.Checked ? 1 : 0)
                        });

                        MessageBox.Show("Клиент успешно обновлен!", "Успех");
                    }

                    dialog.Close();
                    LoadCustomers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblLastName, txtLastName, lblFirstName, txtFirstName, lblMiddleName, txtMiddleName,
                lblPhone, txtPhone, lblEmail, txtEmail, lblAddress, txtAddress, chkDiscount, btnSave
            });

            dialog.ShowDialog(this);
        }

        private void EditCustomer()
        {
            if (dataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите клиента для редактирования!", "Предупреждение");
                return;
            }

            ShowCustomerDialog(dataGridView.SelectedRows[0]);
        }

        private void DeleteCustomer()
        {
            if (selectedCustomerId == -1)
            {
                MessageBox.Show("Выберите клиента для удаления!", "Предупреждение");
                return;
            }

            var result = MessageBox.Show("Удалить выбранного клиента?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    var check = DatabaseHelper.ExecuteQuery(
                        "SELECT COUNT(*) FROM Sales WHERE CustomerID = @id",
                        new[] { new SqlParameter("@id", selectedCustomerId) });

                    if (Convert.ToInt32(check.Rows[0][0]) > 0)
                    {
                        MessageBox.Show("Нельзя удалить клиента с продажами!", "Ошибка");
                        return;
                    }

                    DatabaseHelper.ExecuteNonQuery("DELETE FROM Customers WHERE CustomerID = @id",
                        new[] { new SqlParameter("@id", selectedCustomerId) });

                    MessageBox.Show("Клиент успешно удален!", "Успех");
                    LoadCustomers();
                    selectedCustomerId = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка");
                }
            }
        }
    }
}