﻿using AutoDealershipApp.Database;
using AutoDealershipApp.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AutoDealershipApp.Forms
{
    public partial class LogsForm : Form
    {
        private DataGridView dataGridView;
        private DateTimePicker dtpFrom, dtpTo;
        private ComboBox cmbAction;
        private TextBox txtUser;
        private Panel filterPanel;

        public LogsForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadLogs();
        }

        private void CreateInterface()
        {
            // Панель фильтров
            filterPanel = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(this.ClientSize.Width, 80),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblFrom = new Label { Text = "С:", Location = new Point(10, 15), ForeColor = this.ForeColor, AutoSize = true };
            dtpFrom = new DateTimePicker { Location = new Point(40, 12), Size = new Size(130, 25), Value = DateTime.Today.AddDays(-7), Format = DateTimePickerFormat.Short };

            var lblTo = new Label { Text = "По:", Location = new Point(180, 15), ForeColor = this.ForeColor, AutoSize = true };
            dtpTo = new DateTimePicker { Location = new Point(210, 12), Size = new Size(130, 25), Value = DateTime.Today, Format = DateTimePickerFormat.Short };

            var lblAction = new Label { Text = "Действие:", Location = new Point(350, 15), ForeColor = this.ForeColor, AutoSize = true };
            cmbAction = new ComboBox
            {
                Location = new Point(420, 10),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbAction.Items.AddRange(new[] { "Все действия", "EXECUTE_QUERY", "BACKUP", "LOGIN", "CREATE_SALE", "UPDATE_PRICE" });
            cmbAction.SelectedIndex = 0;

            var lblUser = new Label { Text = "Пользователь:", Location = new Point(580, 15), ForeColor = this.ForeColor, AutoSize = true };
            txtUser = new TextBox
            {
                Location = new Point(670, 10),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            var btnApply = new Button
            {
                Text = "ПРИМЕНИТЬ",
                Location = new Point(840, 5),
                Size = new Size(120, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnApply.Click += (s, e) => LoadLogs();

            var btnExport = new Button
            {
                Text = "ЭКСПОРТ",
                Location = new Point(970, 5),
                Size = new Size(100, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnExport.Click += (s, e) => ExportLogs();

            filterPanel.Controls.AddRange(new Control[] {
                lblFrom, dtpFrom, lblTo, dtpTo, lblAction, cmbAction,
                lblUser, txtUser, btnApply, btnExport
            });

            // DataGridView для логов
            dataGridView = new DataGridView
            {
                Location = new Point(0, 80),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 80),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridView.EnableHeadersVisualStyles = false;

            // Обновляем размеры при изменении размера формы
            this.Resize += (s, e) =>
            {
                filterPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 80);
            };

            this.Controls.Add(filterPanel);
            this.Controls.Add(dataGridView);
        }

        private void LoadLogs()
        {
            string query = @"
                SELECT 
                    LogID AS 'ID',
                    ActionDate AS 'Дата и время',
                    ISNULL(Username, 'Система') AS 'Пользователь',
                    ActionType AS 'Действие',
                    TableName AS 'Таблица',
                    RecordID AS 'ID записи',
                    OldValue AS 'Старое значение',
                    NewValue AS 'Новое значение'
                FROM vw_ActivityLog
                WHERE ActionDate BETWEEN @from AND @to";

            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@from", dtpFrom.Value.Date),
                new SqlParameter("@to", dtpTo.Value.Date.AddDays(1))
            };

            if (cmbAction.SelectedIndex > 0)
            {
                query += " AND ActionType = @action";
                parameters.Add(new SqlParameter("@action", cmbAction.Text));
            }

            if (!string.IsNullOrWhiteSpace(txtUser.Text))
            {
                query += " AND Username LIKE @user";
                parameters.Add(new SqlParameter("@user", $"%{txtUser.Text}%"));
            }

            query += " ORDER BY ActionDate DESC";

            var dt = DatabaseHelper.ExecuteQuery(query, parameters.ToArray());
            dataGridView.DataSource = dt;

            if (dataGridView.Columns["ID"] != null)
                dataGridView.Columns["ID"].Visible = false;
        }

        private void ExportLogs()
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "Excel Files|*.xlsx",
                FileName = $"Logs_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportHelper.ExportToExcel((DataTable)dataGridView.DataSource, sfd.FileName);
            }
        }
    }
}