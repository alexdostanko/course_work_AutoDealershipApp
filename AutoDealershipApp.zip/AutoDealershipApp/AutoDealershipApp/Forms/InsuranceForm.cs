﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using AutoDealershipApp.Database;
using System.Data.SqlClient;

namespace AutoDealershipApp.Forms
{
    public partial class InsuranceForm : Form
    {
        private DataGridView dataGridView;
        private TextBox txtSearch;
        private Button btnAdd, btnEdit, btnDelete;
        private int selectedInsuranceId = -1;

        public InsuranceForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadInsurance();
        }

        private void CreateInterface()
        {
            // Заголовок
            var lblTitle = new Label
            {
                Text = "📄 СТРАХОВЫЕ ПОЛИСЫ",
                Font = new Font("Century Gothic", 18, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(20, 10),
                Size = new Size(400, 40)
            };
            this.Controls.Add(lblTitle);

            // Панель поиска
            var topPanel = new Panel
            {
                Location = new Point(0, 60),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            txtSearch = new TextBox
            {
                Location = new Point(10, 15),
                Size = new Size(300, 30),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtSearch.TextChanged += (s, e) => LoadInsurance(txtSearch.Text);

            var lblSearch = new Label
            {
                Text = "🔍 Поиск:",
                ForeColor = this.ForeColor,
                Location = new Point(320, 18),
                AutoSize = true
            };

            btnAdd = new Button
            {
                Text = "+ НОВЫЙ ПОЛИС",
                Location = new Point(700, 10),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnAdd.Click += (s, e) => ShowInsuranceDialog(null);

            btnEdit = new Button
            {
                Text = "✏ РЕДАКТИРОВАТЬ",
                Location = new Point(850, 10),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnEdit.Click += (s, e) => EditInsurance();

            btnDelete = new Button
            {
                Text = "🗑 УДАЛИТЬ",
                Location = new Point(1000, 10),
                Size = new Size(100, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.Click += (s, e) => DeleteInsurance();

            topPanel.Controls.AddRange(new Control[] { txtSearch, lblSearch, btnAdd, btnEdit, btnDelete });
            this.Controls.Add(topPanel);

            // Таблица страховок
            dataGridView = new DataGridView
            {
                Location = new Point(0, 120),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 120),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.EnableHeadersVisualStyles = false;

            dataGridView.SelectionChanged += (s, e) =>
            {
                if (dataGridView.SelectedRows.Count > 0)
                {
                    selectedInsuranceId = Convert.ToInt32(dataGridView.SelectedRows[0].Cells["ID"].Value);
                }
            };

            this.Controls.Add(dataGridView);

            this.Resize += (s, e) =>
            {
                topPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 120);
            };
        }

        private void LoadInsurance(string searchText = "")
        {
            try
            {
                string query = @"
                    SELECT 
                        i.PolicyID AS 'ID',
                        i.PolicyNumber AS 'Номер полиса',
                        b.BrandName + ' ' + m.ModelName AS 'Автомобиль',
                        cust.LastName + ' ' + cust.FirstName AS 'Клиент',
                        i.InsuranceCompany AS 'Компания',
                        i.PolicyType AS 'Тип',
                        FORMAT(i.Premium, 'N0') + ' ₽' AS 'Премия',
                        CONVERT(NVARCHAR(20), i.StartDate, 104) AS 'С',
                        CONVERT(NVARCHAR(20), i.EndDate, 104) AS 'По'
                    FROM InsurancePolicies i
                    JOIN Sales s ON i.SaleID = s.SaleID
                    JOIN Cars c ON s.CarID = c.CarID
                    JOIN CarModels m ON c.ModelID = m.ModelID
                    JOIN CarBrands b ON m.BrandID = b.BrandID
                    JOIN Customers cust ON s.CustomerID = cust.CustomerID
                    WHERE i.PolicyNumber LIKE @search OR b.BrandName LIKE @search OR cust.LastName LIKE @search
                    ORDER BY i.EndDate";

                var dt = DatabaseHelper.ExecuteQuery(query, new[] {
                    new SqlParameter("@search", $"%{searchText}%")
                });

                dataGridView.DataSource = dt;
                if (dataGridView.Columns["ID"] != null)
                    dataGridView.Columns["ID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки страховок: {ex.Message}");
            }
        }

        private void ShowInsuranceDialog(DataGridViewRow existingRow)
        {
            var dialog = new Form
            {
                Text = existingRow == null ? "Новый страховой полис" : "Редактирование полиса",
                Size = new Size(500, 500),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            // Загружаем продажи без страховок
            var sales = DatabaseHelper.ExecuteQuery(@"
                SELECT s.SaleID, 
                       b.BrandName + ' ' + m.ModelName + ' - ' + cust.LastName AS SaleInfo
                FROM Sales s
                JOIN Cars c ON s.CarID = c.CarID
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                JOIN Customers cust ON s.CustomerID = cust.CustomerID
                LEFT JOIN InsurancePolicies i ON s.SaleID = i.SaleID
                WHERE i.PolicyID IS NULL");

            var lblSale = new Label { Text = "Продажа:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbSale = new ComboBox
            {
                Location = new Point(130, 20),
                Size = new Size(330, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = sales,
                DisplayMember = "SaleInfo",
                ValueMember = "SaleID"
            };

            var lblNumber = new Label { Text = "Номер полиса:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtNumber = new TextBox
            {
                Location = new Point(130, 60),
                Size = new Size(200, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                Text = "INS-" + DateTime.Now.ToString("yyyyMMdd-") + new Random().Next(1000, 9999)
            };

            var lblCompany = new Label { Text = "Компания:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbCompany = new ComboBox
            {
                Location = new Point(130, 100),
                Size = new Size(200, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbCompany.Items.AddRange(new[] { "Ингосстрах", "РЕСО", "АльфаСтрахование", "СОГАЗ", "ВСК" });

            var lblType = new Label { Text = "Тип:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbType = new ComboBox
            {
                Location = new Point(130, 140),
                Size = new Size(200, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbType.Items.AddRange(new[] { "ОСАГО", "КАСКО", "ДСАГО" });

            var lblPremium = new Label { Text = "Премия:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtPremium = new TextBox
            {
                Location = new Point(130, 180),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ? Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var lblStart = new Label { Text = "Дата начала:", Location = new Point(20, 220), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var dtpStart = new DateTimePicker
            {
                Location = new Point(130, 220),
                Size = new Size(150, 25),
                Value = DateTime.Now,
                Format = DateTimePickerFormat.Short
            };

            var lblEnd = new Label { Text = "Дата окончания:", Location = new Point(20, 260), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var dtpEnd = new DateTimePicker
            {
                Location = new Point(130, 260),
                Size = new Size(150, 25),
                Value = DateTime.Now.AddYears(1),
                Format = DateTimePickerFormat.Short
            };

            var btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Location = new Point(130, 330),
                Size = new Size(200, 40),
                BackColor = btnAdd.BackColor,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            // Заполняем при редактировании
            if (existingRow != null)
            {
                cmbSale.Enabled = false;
                txtNumber.Text = existingRow.Cells["Номер полиса"].Value.ToString();
                cmbCompany.Text = existingRow.Cells["Компания"].Value.ToString();
                cmbType.Text = existingRow.Cells["Тип"].Value.ToString();
                txtPremium.Text = existingRow.Cells["Премия"].Value.ToString().Replace(" ₽", "").Replace(" ", "");

                // Получаем полные данные для дат
                int id = Convert.ToInt32(existingRow.Cells["ID"].Value);
                var policyData = DatabaseHelper.ExecuteQuery(
                    "SELECT StartDate, EndDate FROM InsurancePolicies WHERE PolicyID = @id",
                    new[] { new SqlParameter("@id", id) });

                if (policyData.Rows.Count > 0)
                {
                    dtpStart.Value = Convert.ToDateTime(policyData.Rows[0]["StartDate"]);
                    dtpEnd.Value = Convert.ToDateTime(policyData.Rows[0]["EndDate"]);
                }
            }

            btnSave.Click += (s, e) =>
            {
                if (cmbSale.SelectedValue == null && existingRow == null)
                {
                    MessageBox.Show("Выберите продажу!");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtNumber.Text) || string.IsNullOrWhiteSpace(txtPremium.Text))
                {
                    MessageBox.Show("Заполните все поля!");
                    return;
                }

                try
                {
                    if (existingRow == null)
                    {
                        string query = @"
                            INSERT INTO InsurancePolicies (SaleID, PolicyNumber, InsuranceCompany, PolicyType, 
                                                          StartDate, EndDate, Premium)
                            VALUES (@sale, @num, @company, @type, @start, @end, @prem)";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@sale", cmbSale.SelectedValue),
                            new SqlParameter("@num", txtNumber.Text),
                            new SqlParameter("@company", cmbCompany.Text),
                            new SqlParameter("@type", cmbType.Text),
                            new SqlParameter("@start", dtpStart.Value),
                            new SqlParameter("@end", dtpEnd.Value),
                            new SqlParameter("@prem", decimal.Parse(txtPremium.Text))
                        });
                    }
                    else
                    {
                        int id = Convert.ToInt32(existingRow.Cells["ID"].Value);
                        string query = @"
                            UPDATE InsurancePolicies 
                            SET PolicyNumber=@num, InsuranceCompany=@company, PolicyType=@type,
                                StartDate=@start, EndDate=@end, Premium=@prem
                            WHERE PolicyID=@id";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@id", id),
                            new SqlParameter("@num", txtNumber.Text),
                            new SqlParameter("@company", cmbCompany.Text),
                            new SqlParameter("@type", cmbType.Text),
                            new SqlParameter("@start", dtpStart.Value),
                            new SqlParameter("@end", dtpEnd.Value),
                            new SqlParameter("@prem", decimal.Parse(txtPremium.Text))
                        });
                    }

                    MessageBox.Show("Страховой полис сохранен!");
                    dialog.Close();
                    LoadInsurance();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblSale, cmbSale, lblNumber, txtNumber, lblCompany, cmbCompany,
                lblType, cmbType, lblPremium, txtPremium, lblStart, dtpStart,
                lblEnd, dtpEnd, btnSave
            });

            dialog.ShowDialog(this);
        }

        private void EditInsurance()
        {
            if (dataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите полис для редактирования!");
                return;
            }
            ShowInsuranceDialog(dataGridView.SelectedRows[0]);
        }

        private void DeleteInsurance()
        {
            if (selectedInsuranceId == -1)
            {
                MessageBox.Show("Выберите полис для удаления!");
                return;
            }

            var result = MessageBox.Show("Удалить страховой полис?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    DatabaseHelper.ExecuteNonQuery("DELETE FROM InsurancePolicies WHERE PolicyID = @id",
                        new[] { new SqlParameter("@id", selectedInsuranceId) });
                    LoadInsurance();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
        }
    }
}