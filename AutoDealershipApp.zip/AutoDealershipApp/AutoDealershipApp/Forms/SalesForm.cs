﻿using AutoDealershipApp.Database;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace AutoDealershipApp.Forms
{
    public partial class SalesForm : Form
    {
        private DataGridView dataGridView;
        private ComboBox cmbPeriod;
        private DateTimePicker dtpFrom, dtpTo;
        private Label lblTotal, lblCount;
        private Panel filterPanel, statsPanel;

        public SalesForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadSales();
        }

        private void CreateInterface()
        {
            // Панель фильтров
            filterPanel = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            var lblPeriod = new Label { Text = "Период:", Location = new Point(10, 20), ForeColor = this.ForeColor, AutoSize = true };

            cmbPeriod = new ComboBox
            {
                Location = new Point(70, 17),
                Size = new Size(120, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbPeriod.Items.AddRange(new[] { "Все время", "Сегодня", "Неделя", "Месяц", "Год", "Произвольно" });
            cmbPeriod.SelectedIndex = 0;
            cmbPeriod.SelectedIndexChanged += (s, e) => UpdateDateRange();

            dtpFrom = new DateTimePicker
            {
                Location = new Point(200, 17),
                Size = new Size(130, 25),
                Value = DateTime.Now.AddMonths(-1),
                Format = DateTimePickerFormat.Short,
                Enabled = false
            };
            dtpTo = new DateTimePicker
            {
                Location = new Point(340, 17),
                Size = new Size(130, 25),
                Value = DateTime.Now,
                Format = DateTimePickerFormat.Short,
                Enabled = false
            };

            var btnApply = new Button
            {
                Text = "ПРИМЕНИТЬ",
                Location = new Point(480, 10),
                Size = new Size(120, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnApply.Click += (s, e) => LoadSales();

            var btnNewSale = new Button
            {
                Text = "+ НОВАЯ ПРОДАЖА",
                Location = new Point(1000, 10),
                Size = new Size(150, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnNewSale.Click += (s, e) => ShowSaleDialog();

            filterPanel.Controls.AddRange(new Control[] { lblPeriod, cmbPeriod, dtpFrom, dtpTo, btnApply, btnNewSale });

            // Панель статистики
            statsPanel = new Panel
            {
                Location = new Point(0, 60),
                Size = new Size(this.ClientSize.Width, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(30, 30, 30) : Color.FromArgb(230, 230, 230),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            lblCount = new Label
            {
                Location = new Point(10, 10),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                AutoSize = true
            };
            lblTotal = new Label
            {
                Location = new Point(300, 10),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                AutoSize = true
            };
            statsPanel.Controls.AddRange(new Control[] { lblCount, lblTotal });

            // DataGridView для продаж
            dataGridView = new DataGridView
            {
                Location = new Point(0, 100),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 100),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridView.EnableHeadersVisualStyles = false;

            // Обновляем размеры при изменении размера формы
            this.Resize += (s, e) =>
            {
                filterPanel.Width = this.ClientSize.Width;
                statsPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 100);
            };

            this.Controls.Add(filterPanel);
            this.Controls.Add(statsPanel);
            this.Controls.Add(dataGridView);
        }

        // ... остальные методы (UpdateDateRange, LoadSales, UpdateStatistics, ShowSaleDialog) остаются без изменений ...
        private void UpdateDateRange()
        {
            bool custom = cmbPeriod.SelectedIndex == 5;
            dtpFrom.Enabled = custom;
            dtpTo.Enabled = custom;

            if (!custom)
            {
                switch (cmbPeriod.SelectedIndex)
                {
                    case 1:
                        dtpFrom.Value = DateTime.Today;
                        dtpTo.Value = DateTime.Today;
                        break;
                    case 2:
                        dtpFrom.Value = DateTime.Today.AddDays(-7);
                        dtpTo.Value = DateTime.Today;
                        break;
                    case 3:
                        dtpFrom.Value = DateTime.Today.AddMonths(-1);
                        dtpTo.Value = DateTime.Today;
                        break;
                    case 4:
                        dtpFrom.Value = DateTime.Today.AddYears(-1);
                        dtpTo.Value = DateTime.Today;
                        break;
                }
            }
        }

        private void LoadSales()
        {
            string query = @"
                SELECT 
                    s.SaleID AS 'ID',
                    CONVERT(NVARCHAR(20), s.SaleDate, 104) AS 'Дата',
                    b.BrandName + ' ' + m.ModelName AS 'Автомобиль',
                    c.VIN,
                    cust.LastName + ' ' + cust.FirstName AS 'Клиент',
                    e.LastName + ' ' + e.FirstName AS 'Менеджер',
                    FORMAT(s.FinalPrice, 'N0') + ' ₽' AS 'Цена',
                    s.PaymentMethod AS 'Оплата'
                FROM Sales s
                JOIN Cars c ON s.CarID = c.CarID
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                JOIN Customers cust ON s.CustomerID = cust.CustomerID
                JOIN Employees e ON s.EmployeeID = e.EmployeeID";

            if (cmbPeriod.SelectedIndex > 0)
            {
                query += $" WHERE s.SaleDate BETWEEN '{dtpFrom.Value:yyyy-MM-dd}' AND '{dtpTo.Value:yyyy-MM-dd}'";
            }

            query += " ORDER BY s.SaleDate DESC";

            var dt = DatabaseHelper.ExecuteQuery(query);
            dataGridView.DataSource = dt;

            if (dataGridView.Columns["ID"] != null)
                dataGridView.Columns["ID"].Visible = false;

            UpdateStatistics(dt);
        }

        private void UpdateStatistics(DataTable dt)
        {
            int count = dt.Rows.Count;
            decimal total = 0;

            foreach (DataRow row in dt.Rows)
            {
                string priceStr = row["Цена"].ToString().Replace(" ₽", "").Replace(" ", "");
                if (decimal.TryParse(priceStr, out decimal price))
                    total += price;
            }

            lblCount.Text = $"📊 Всего продаж: {count}";
            lblTotal.Text = $"💰 Общая выручка: {total:N0} ₽";
        }

        private void ShowSaleDialog()
        {
            var dialog = new Form
            {
                Text = "Новая продажа",
                Size = new Size(500, 500),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            var cars = DatabaseHelper.ExecuteQuery(@"
                SELECT c.CarID, b.BrandName + ' ' + m.ModelName + ' (' + c.VIN + ')' AS CarName
                FROM Cars c
                JOIN CarModels m ON c.ModelID = m.ModelID
                JOIN CarBrands b ON m.BrandID = b.BrandID
                WHERE c.Status = 'В наличии'");

            var customers = DatabaseHelper.ExecuteQuery("SELECT CustomerID, LastName + ' ' + FirstName AS CustomerName FROM Customers");
            var employees = DatabaseHelper.ExecuteQuery("SELECT EmployeeID, LastName + ' ' + FirstName AS EmployeeName FROM Employees WHERE Position LIKE '%Продавец%' OR Position LIKE '%Менеджер%'");

            var lblCar = new Label { Text = "Автомобиль:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbCar = new ComboBox
            {
                Location = new Point(130, 20),
                Size = new Size(320, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = cars,
                DisplayMember = "CarName",
                ValueMember = "CarID"
            };

            var lblCustomer = new Label { Text = "Клиент:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbCustomer = new ComboBox
            {
                Location = new Point(130, 60),
                Size = new Size(320, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = customers,
                DisplayMember = "CustomerName",
                ValueMember = "CustomerID"
            };

            var lblEmployee = new Label { Text = "Менеджер:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbEmployee = new ComboBox
            {
                Location = new Point(130, 100),
                Size = new Size(320, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                DataSource = employees,
                DisplayMember = "EmployeeName",
                ValueMember = "EmployeeID"
            };

            var lblPrice = new Label { Text = "Цена:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtPrice = new TextBox
            {
                Location = new Point(130, 140),
                Size = new Size(150, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblPayment = new Label { Text = "Оплата:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbPayment = new ComboBox
            {
                Location = new Point(130, 180),
                Size = new Size(150, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };
            cmbPayment.Items.AddRange(new[] { "Наличные", "Карта", "Кредит", "Trade-in" });

            var lblNotes = new Label { Text = "Примечания:", Location = new Point(20, 220), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtNotes = new TextBox
            {
                Location = new Point(130, 220),
                Size = new Size(320, 50),
                Multiline = true,
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };

            var btnSave = new Button
            {
                Text = "ОФОРМИТЬ ПРОДАЖУ",
                Location = new Point(130, 300),
                Size = new Size(220, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            btnSave.Click += (s, e) =>
            {
                if (cmbCar.SelectedValue == null || cmbCustomer.SelectedValue == null ||
                    cmbEmployee.SelectedValue == null || string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Заполните все поля!", "Ошибка");
                    return;
                }

                try
                {
                    string query = @"
                        INSERT INTO Sales (CarID, CustomerID, EmployeeID, SaleDate, FinalPrice, PaymentMethod, Notes)
                        VALUES (@car, @cust, @emp, GETDATE(), @price, @pay, @notes)";

                    DatabaseHelper.ExecuteNonQuery(query, new[] {
                        new SqlParameter("@car", cmbCar.SelectedValue),
                        new SqlParameter("@cust", cmbCustomer.SelectedValue),
                        new SqlParameter("@emp", cmbEmployee.SelectedValue),
                        new SqlParameter("@price", decimal.Parse(txtPrice.Text)),
                        new SqlParameter("@pay", cmbPayment.Text),
                        new SqlParameter("@notes", txtNotes.Text)
                    });

                    MessageBox.Show("Продажа успешно оформлена!", "Успех");
                    dialog.Close();
                    LoadSales();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblCar, cmbCar, lblCustomer, cmbCustomer, lblEmployee, cmbEmployee,
                lblPrice, txtPrice, lblPayment, cmbPayment, lblNotes, txtNotes, btnSave
            });

            dialog.ShowDialog(this);
        }
    }
}