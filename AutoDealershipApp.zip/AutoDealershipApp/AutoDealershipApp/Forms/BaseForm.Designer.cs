﻿namespace AutoDealershipApp
{
    partial class BaseForm
    {
        private System.ComponentModel.IContainer components = null;

        // УДАЛИТЕ ЭТОТ МЕТОД, ЕСЛИ ОН ЕСТЬ:
        // protected override void Dispose(bool disposing)
        // {
        //     if (disposing && (components != null))
        //     {
        //         components.Dispose();
        //     }
        //     base.Dispose(disposing);
        // }

        private void InitializeComponent()
        {
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Name = "BaseForm";
            this.Text = "BaseForm";
        }
    }
}