﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using AutoDealershipApp.Database;
using System.Data.SqlClient;

namespace AutoDealershipApp.Forms
{
    public partial class EmployeesForm : Form
    {
        private DataGridView dataGridView;
        private TextBox txtSearch;
        private Button btnAdd, btnEdit, btnDelete;
        private int selectedEmployeeId = -1;
        private ComboBox cmbRole;

        public EmployeesForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            LoadEmployees();
        }

        private void CreateInterface()
        {
            // Панель поиска
            var topPanel = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(this.ClientSize.Width, 60),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };

            txtSearch = new TextBox
            {
                Location = new Point(10, 15),
                Size = new Size(300, 30),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.FixedSingle
            };
            txtSearch.TextChanged += (s, e) => LoadEmployees(txtSearch.Text);

            var lblSearch = new Label
            {
                Text = "🔍 Поиск:",
                ForeColor = this.ForeColor,
                Location = new Point(320, 18),
                AutoSize = true
            };

            btnAdd = new Button
            {
                Text = "+ ДОБАВИТЬ",
                Location = new Point(800, 10),
                Size = new Size(120, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnAdd.Click += (s, e) => ShowEmployeeDialog(null);

            btnEdit = new Button
            {
                Text = "✏ РЕДАКТИРОВАТЬ",
                Location = new Point(930, 10),
                Size = new Size(140, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnEdit.Click += (s, e) => EditEmployee();

            btnDelete = new Button
            {
                Text = "🗑 УДАЛИТЬ",
                Location = new Point(1080, 10),
                Size = new Size(100, 40),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.FromArgb(200, 200, 200),
                ForeColor = this.ForeColor,
                FlatStyle = FlatStyle.Flat
            };
            btnDelete.Click += (s, e) => DeleteEmployee();

            topPanel.Controls.AddRange(new Control[] { txtSearch, lblSearch, btnAdd, btnEdit, btnDelete });

            // Таблица сотрудников
            dataGridView = new DataGridView
            {
                Location = new Point(0, 60),
                Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 60),
                BackgroundColor = this.BackColor,
                ForeColor = this.ForeColor,
                GridColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(80, 80, 80) : Color.FromArgb(200, 200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            dataGridView.DefaultCellStyle.BackColor = this.BackColor;
            dataGridView.DefaultCellStyle.ForeColor = this.ForeColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120);
            dataGridView.EnableHeadersVisualStyles = false;

            dataGridView.SelectionChanged += (s, e) =>
            {
                if (dataGridView.SelectedRows.Count > 0)
                {
                    selectedEmployeeId = Convert.ToInt32(dataGridView.SelectedRows[0].Cells["ID"].Value);
                }
            };

            this.Resize += (s, e) =>
            {
                topPanel.Width = this.ClientSize.Width;
                dataGridView.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 60);
            };

            this.Controls.Add(topPanel);
            this.Controls.Add(dataGridView);
        }

        private void LoadEmployees(string searchText = "")
        {
            string query = @"
                SELECT 
                    e.EmployeeID AS 'ID',
                    e.LastName + ' ' + e.FirstName AS 'ФИО',
                    e.Position AS 'Должность',
                    e.Phone AS 'Телефон',
                    e.Email AS 'Email',
                    e.HireDate AS 'Дата найма',
                    r.RoleName AS 'Роль'
                FROM Employees e
                LEFT JOIN Roles r ON e.RoleID = r.RoleID
                WHERE e.LastName LIKE @search OR e.FirstName LIKE @search OR e.Phone LIKE @search
                ORDER BY e.EmployeeID";

            var dt = DatabaseHelper.ExecuteQuery(query, new[] {
                new SqlParameter("@search", $"%{searchText}%")
            });

            dataGridView.DataSource = dt;
            if (dataGridView.Columns["ID"] != null)
                dataGridView.Columns["ID"].Visible = false;
        }

        private void ShowEmployeeDialog(DataGridViewRow existingRow)
        {
            var dialog = new Form
            {
                Text = existingRow == null ? "Добавление сотрудника" : "Редактирование сотрудника",
                Size = new Size(450, 500),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor
            };

            // Поля формы
            var lblLastName = new Label { Text = "Фамилия:", Location = new Point(20, 20), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtLastName = new TextBox { Location = new Point(130, 20), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor };

            var lblFirstName = new Label { Text = "Имя:", Location = new Point(20, 60), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtFirstName = new TextBox { Location = new Point(130, 60), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor };

            var lblPosition = new Label { Text = "Должность:", Location = new Point(20, 100), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtPosition = new TextBox { Location = new Point(130, 100), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor };

            var lblPhone = new Label { Text = "Телефон:", Location = new Point(20, 140), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtPhone = new TextBox { Location = new Point(130, 140), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor };

            var lblEmail = new Label { Text = "Email:", Location = new Point(20, 180), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var txtEmail = new TextBox { Location = new Point(130, 180), Size = new Size(280, 25), BackColor = txtSearch.BackColor, ForeColor = this.ForeColor };

            var lblHireDate = new Label { Text = "Дата найма:", Location = new Point(20, 220), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var dtpHire = new DateTimePicker { Location = new Point(130, 220), Size = new Size(280, 25), Value = DateTime.Now };

            var lblRole = new Label { Text = "Роль:", Location = new Point(20, 260), Size = new Size(100, 25), ForeColor = this.ForeColor };
            var cmbRole = new ComboBox
            {
                Location = new Point(130, 260),
                Size = new Size(280, 25),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = txtSearch.BackColor,
                ForeColor = this.ForeColor
            };

            // Загружаем роли
            var roles = DatabaseHelper.ExecuteQuery("SELECT RoleID, RoleName FROM Roles");
            cmbRole.DataSource = roles;
            cmbRole.DisplayMember = "RoleName";
            cmbRole.ValueMember = "RoleID";

            var btnSave = new Button
            {
                Text = "СОХРАНИТЬ",
                Location = new Point(130, 320),
                Size = new Size(180, 40),
                BackColor = btnAdd.BackColor,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };

            // Заполняем при редактировании
            if (existingRow != null)
            {
                string[] nameParts = existingRow.Cells["ФИО"].Value.ToString().Split(' ');
                txtLastName.Text = nameParts[0];
                txtFirstName.Text = nameParts.Length > 1 ? nameParts[1] : "";
                txtPosition.Text = existingRow.Cells["Должность"].Value.ToString();
                txtPhone.Text = existingRow.Cells["Телефон"].Value.ToString();
                txtEmail.Text = existingRow.Cells["Email"].Value.ToString();
                dtpHire.Value = Convert.ToDateTime(existingRow.Cells["Дата найма"].Value);
                cmbRole.Text = existingRow.Cells["Роль"].Value.ToString();
            }

            btnSave.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtFirstName.Text))
                {
                    MessageBox.Show("Заполните фамилию и имя!");
                    return;
                }

                try
                {
                    if (existingRow == null)
                    {
                        string query = @"
                            INSERT INTO Employees (LastName, FirstName, Position, Phone, Email, HireDate, RoleID)
                            VALUES (@ln, @fn, @pos, @phone, @email, @date, @role)";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@ln", txtLastName.Text),
                            new SqlParameter("@fn", txtFirstName.Text),
                            new SqlParameter("@pos", txtPosition.Text),
                            new SqlParameter("@phone", txtPhone.Text),
                            new SqlParameter("@email", txtEmail.Text),
                            new SqlParameter("@date", dtpHire.Value),
                            new SqlParameter("@role", cmbRole.SelectedValue)
                        });
                    }
                    else
                    {
                        int id = Convert.ToInt32(existingRow.Cells["ID"].Value);
                        string query = @"
                            UPDATE Employees 
                            SET LastName=@ln, FirstName=@fn, Position=@pos, 
                                Phone=@phone, Email=@email, HireDate=@date, RoleID=@role
                            WHERE EmployeeID=@id";

                        DatabaseHelper.ExecuteNonQuery(query, new[] {
                            new SqlParameter("@id", id),
                            new SqlParameter("@ln", txtLastName.Text),
                            new SqlParameter("@fn", txtFirstName.Text),
                            new SqlParameter("@pos", txtPosition.Text),
                            new SqlParameter("@phone", txtPhone.Text),
                            new SqlParameter("@email", txtEmail.Text),
                            new SqlParameter("@date", dtpHire.Value),
                            new SqlParameter("@role", cmbRole.SelectedValue)
                        });
                    }

                    dialog.Close();
                    LoadEmployees();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            };

            dialog.Controls.AddRange(new Control[] {
                lblLastName, txtLastName, lblFirstName, txtFirstName, lblPosition, txtPosition,
                lblPhone, txtPhone, lblEmail, txtEmail, lblHireDate, dtpHire, lblRole, cmbRole, btnSave
            });

            dialog.ShowDialog(this);
        }

        private void EditEmployee()
        {
            if (dataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите сотрудника!");
                return;
            }
            ShowEmployeeDialog(dataGridView.SelectedRows[0]);
        }

        private void DeleteEmployee()
        {
            if (selectedEmployeeId == -1)
            {
                MessageBox.Show("Выберите сотрудника!");
                return;
            }

            var result = MessageBox.Show("Удалить сотрудника?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    DatabaseHelper.ExecuteNonQuery("DELETE FROM Employees WHERE EmployeeID = @id",
                        new[] { new SqlParameter("@id", selectedEmployeeId) });
                    LoadEmployees();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
        }
    }
}