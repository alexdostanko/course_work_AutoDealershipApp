﻿using AutoDealershipApp.Database;
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AutoDealershipApp.Forms
{
    public partial class BackupForm : Form
    {
        private TextBox txtBackupPath;
        private TextBox txtRestorePath;
        private Label lblStatus;

        public BackupForm()
        {
            this.BackColor = Properties.Settings.Default.IsDarkTheme ?
                Color.FromArgb(20, 20, 20) : Color.FromArgb(255, 255, 255);
            this.ForeColor = Properties.Settings.Default.IsDarkTheme ?
                Color.White : Color.Black;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Dock = DockStyle.Fill;

            CreateInterface();
            UpdateStatus();
        }

        private void CreateInterface()
        {
            // Заголовок
            var lblTitle = new Label
            {
                Text = "💾 РЕЗЕРВНОЕ КОПИРОВАНИЕ",
                Font = new Font("Century Gothic", 20, FontStyle.Bold),
                ForeColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                Location = new Point(30, 30),
                Size = new Size(600, 40),
                TextAlign = ContentAlignment.MiddleLeft
            };

            // ===== РАЗДЕЛ СОЗДАНИЯ БЭКАПА =====
            var groupBackup = new GroupBox
            {
                Text = "Создание резервной копии",
                Location = new Point(30, 100),
                Size = new Size(600, 150),
                ForeColor = this.ForeColor,
                BackColor = this.BackColor
            };

            var lblBackupPath = new Label
            {
                Text = "Путь для сохранения:",
                Location = new Point(20, 30),
                Size = new Size(150, 25),
                ForeColor = this.ForeColor
            };

            txtBackupPath = new TextBox
            {
                Location = new Point(20, 60),
                Size = new Size(400, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor,
                Text = @"C:\Backup\"
            };

            var btnBrowseBackup = new Button
            {
                Text = "Обзор",
                Location = new Point(430, 60),
                Size = new Size(80, 27),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnBrowseBackup.Click += (s, e) => BrowseBackupFolder();

            var btnCreateBackup = new Button
            {
                Text = "СОЗДАТЬ БЭКАП",
                Location = new Point(20, 100),
                Size = new Size(200, 35),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnCreateBackup.Click += (s, e) => CreateBackup();

            groupBackup.Controls.AddRange(new Control[] {
                lblBackupPath, txtBackupPath, btnBrowseBackup, btnCreateBackup
            });

            // ===== РАЗДЕЛ ВОССТАНОВЛЕНИЯ =====
            var groupRestore = new GroupBox
            {
                Text = "Восстановление из резервной копии",
                Location = new Point(30, 270),
                Size = new Size(600, 150),
                ForeColor = this.ForeColor,
                BackColor = this.BackColor
            };

            var lblRestorePath = new Label
            {
                Text = "Путь к файлу бэкапа:",
                Location = new Point(20, 30),
                Size = new Size(150, 25),
                ForeColor = this.ForeColor
            };

            txtRestorePath = new TextBox
            {
                Location = new Point(20, 60),
                Size = new Size(400, 25),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(60, 60, 60) : Color.White,
                ForeColor = this.ForeColor
            };

            var btnBrowseRestore = new Button
            {
                Text = "Обзор",
                Location = new Point(430, 60),
                Size = new Size(80, 27),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(0, 255, 200) : Color.FromArgb(0, 150, 120),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat
            };
            btnBrowseRestore.Click += (s, e) => BrowseRestoreFile();

            var btnRestore = new Button
            {
                Text = "ВОССТАНОВИТЬ",
                Location = new Point(20, 100),
                Size = new Size(200, 35),
                BackColor = Color.Orange,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            btnRestore.Click += (s, e) => RestoreBackup();

            groupRestore.Controls.AddRange(new Control[] {
                lblRestorePath, txtRestorePath, btnBrowseRestore, btnRestore
            });

            // ===== СТАТУС =====
            var statusPanel = new Panel
            {
                Location = new Point(30, 440),
                Size = new Size(600, 80),
                BackColor = Properties.Settings.Default.IsDarkTheme ?
                    Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 240, 240)
            };

            lblStatus = new Label
            {
                Text = "Готов к работе",
                Location = new Point(10, 10),
                Size = new Size(580, 60),
                ForeColor = this.ForeColor,
                Font = new Font("Segoe UI", 10)
            };

            statusPanel.Controls.Add(lblStatus);

            // Добавляем все на форму
            this.Controls.Add(lblTitle);
            this.Controls.Add(groupBackup);
            this.Controls.Add(groupRestore);
            this.Controls.Add(statusPanel);
        }

        private void BrowseBackupFolder()
        {
            using (var fbd = new FolderBrowserDialog())
            {
                fbd.Description = "Выберите папку для сохранения бэкапа";
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    txtBackupPath.Text = fbd.SelectedPath;
                }
            }
        }

        private void BrowseRestoreFile()
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Backup files (*.bak)|*.bak";
                ofd.Title = "Выберите файл резервной копии";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    txtRestorePath.Text = ofd.FileName;
                }
            }
        }

        private void CreateBackup()
        {
            try
            {
                if (!Directory.Exists(txtBackupPath.Text))
                {
                    Directory.CreateDirectory(txtBackupPath.Text);
                }

                lblStatus.Text = "⏳ Создание резервной копии...";
                Application.DoEvents();

                string fileName = $"AutoDealership_Backup_{DateTime.Now:yyyyMMdd_HHmmss}.bak";
                string fullPath = Path.Combine(txtBackupPath.Text, fileName);

                string query = $"BACKUP DATABASE AutoDealership TO DISK = '{fullPath}'";
                DatabaseHelper.ExecuteNonQuery(query);

                lblStatus.Text = $"✅ Бэкап успешно создан!\n📁 {fullPath}";

                // Логируем
                DatabaseHelper.ExecuteNonQuery(
                    "INSERT INTO Logs (ActionType, TableName, NewValue, ActionDate) VALUES ('BACKUP', 'DATABASE', @path, GETDATE())",
                    new[] { new SqlParameter("@path", fullPath) });
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"❌ Ошибка: {ex.Message}";
            }
        }

        private void RestoreBackup()
        {
            if (string.IsNullOrEmpty(txtRestorePath.Text) || !File.Exists(txtRestorePath.Text))
            {
                MessageBox.Show("Файл не найден!", "Ошибка");
                return;
            }

            var result = MessageBox.Show(
                "⚠️ ВНИМАНИЕ! Восстановление удалит все текущие данные!\n\nПродолжить?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                try
                {
                    lblStatus.Text = "⏳ Восстановление базы данных...";
                    Application.DoEvents();

                    string query = $@"
                        ALTER DATABASE AutoDealership SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                        RESTORE DATABASE AutoDealership FROM DISK = '{txtRestorePath.Text}' WITH REPLACE;
                        ALTER DATABASE AutoDealership SET MULTI_USER;";

                    DatabaseHelper.ExecuteNonQuery(query);

                    lblStatus.Text = $"✅ База данных успешно восстановлена из:\n📁 {txtRestorePath.Text}";

                    // Логируем
                    DatabaseHelper.ExecuteNonQuery(
                        "INSERT INTO Logs (ActionType, TableName, NewValue, ActionDate) VALUES ('RESTORE', 'DATABASE', @path, GETDATE())",
                        new[] { new SqlParameter("@path", txtRestorePath.Text) });
                }
                catch (Exception ex)
                {
                    lblStatus.Text = $"❌ Ошибка: {ex.Message}";
                }
            }
        }

        private void UpdateStatus()
        {
            // Проверяем размер БД и последний бэкап
            try
            {
                var dt = DatabaseHelper.ExecuteQuery(@"
                    SELECT 
                        SUM(size * 8 / 1024) as SizeMB
                    FROM sys.master_files 
                    WHERE database_id = DB_ID('AutoDealership')");

                int size = Convert.ToInt32(dt.Rows[0][0]);

                var lastBackup = DatabaseHelper.ExecuteQuery(@"
                    SELECT TOP 1 NewValue, ActionDate 
                    FROM Logs 
                    WHERE ActionType = 'BACKUP' 
                    ORDER BY ActionDate DESC");

                if (lastBackup.Rows.Count > 0)
                {
                    lblStatus.Text = $"📊 Размер БД: {size} MB\n" +
                                    $"📅 Последний бэкап: {lastBackup.Rows[0]["ActionDate"]}\n" +
                                    $"📁 {lastBackup.Rows[0]["NewValue"]}";
                }
                else
                {
                    lblStatus.Text = $"📊 Размер БД: {size} MB\n📅 Бэкапов еще не было";
                }
            }
            catch
            {
                lblStatus.Text = "Готов к работе";
            }
        }
    }
}